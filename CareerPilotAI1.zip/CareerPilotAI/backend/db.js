
// Load environment variables
require("dotenv").config();

// Import required modules
const mysql = require("mysql2/promise");
const fs = require("fs");

// Create database connection pool
const db = mysql.createPool({

    host: process.env.DB_HOST,

    user: process.env.DB_USER,

    password: process.env.DB_PASSWORD,

    database: process.env.DB_NAME,

    port: Number(process.env.DB_PORT),

    // Secure connection to TiDB Cloud
    ssl: {
        ca: fs.readFileSync(process.env.DB_SSL_CA_PATH)
    },

    waitForConnections: true,

    connectionLimit: 10,

    queueLimit: 0

});

// Test database connection
async function testDatabaseConnection() {

    try {

        const connection = await db.getConnection();

        console.log("TiDB Cloud Database Connected Successfully!");

        connection.release();

    } catch (error) {

        console.error(
            "Database Connection Failed:",
            error.message
        );

    }

}

// Export database connection
module.exports = {
    db,
    testDatabaseConnection
};
