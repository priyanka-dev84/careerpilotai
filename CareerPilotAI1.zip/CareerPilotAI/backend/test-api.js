
async function testStudentAPI() {

    try {

        const response = await fetch(
            "http://localhost:3000/api/student",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    name: "Rahul Kumar",
                    email: "rahul@example.com",
                    department: "CSE",
                    year: 2
                })
            }
        );

        const data = await response.json();

        console.log("API Response:", data);

    } catch (error) {

        console.error("API Test Failed:", error);

    }

}

testStudentAPI();
