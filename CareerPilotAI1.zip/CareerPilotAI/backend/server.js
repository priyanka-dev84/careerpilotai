const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const { db, testDatabaseConnection } = require("./db");
const session = require("express-session");
const MySQLStore = require("express-mysql-session")(session);

const app = express();
const PORT = process.env.PORT || 3000;
const sessionStore = new MySQLStore({
    createDatabaseTable: true,
    clearExpired: true,
    checkExpirationInterval: 900000,
    expiration: 86400000
}, db);
// Middleware
// Trust Render's reverse proxy in production
if (process.env.NODE_ENV === "production") {
    app.set("trust proxy", 1);
}

// CORS configuration
app.use(cors({
    origin: process.env.FRONTEND_URL || "http://localhost:5500",
    credentials: true
}));

app.use(express.json());
app.use(session({
    key: "careerpilot.sid",
    secret: process.env.SESSION_SECRET,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
    maxAge: 24 * 60 * 60 * 1000
}
}));

// Authentication Middleware
function requireAuth(req, res, next) {

    // Check whether the student is logged in
    if (!req.session || !req.session.studentId) {
        return res.status(401).json({
            success: false,
            message: "Authentication required. Please log in."
        });
    }

    // Authenticated student: continue to the requested API
    next();
}
// Home route
app.get("/", (req, res) => {
    res.send("Welcome to CareerPilot AI Backend!");
});

// Backend status
app.get("/api/status", (req, res) => {
    res.json({
        success: true,
        message: "CareerPilot AI Backend is running successfully!"
    });
});

// Student registration API
app.post("/api/student", async (req, res) => {
    try {
        const {
            studentName,
            email,
            college,
            department,
            year,
            semester,
            password,
            confirmPassword
        } = req.body;

        // Validate required fields
        if (
            !studentName ||
            !email ||
            !college ||
            !department ||
            !year ||
            !semester ||
            !password ||
            !confirmPassword
        ) {
            return res.status(400).json({
                success: false,
                message: "Please fill in all required fields."
            });
        }

        // Validate password
        if (password.length < 8) {
            return res.status(400).json({
                success: false,
                message: "Password must contain at least 8 characters."
            });
        }

        if (password !== confirmPassword) {
            return res.status(400).json({
                success: false,
                message: "Passwords do not match."
            });
        }

        // Hash password
        const passwordHash = await bcrypt.hash(password, 10);

        // Save student in MySQL
        const sql = `
            INSERT INTO students
            (
                student_name,
                email,
                college,
                department,
                current_year,
                current_semester,
                password_hash
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

        const values = [
            studentName,
            email,
            college,
            department,
            Number(year),
            Number(semester),
            passwordHash
        ];

        const [result] = await db.execute(sql, values);

        // Successful registration
        res.status(201).json({
            success: true,
            message: "Student registered successfully!",
            studentId: result.insertId
        });

    } catch (error) {

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                success: false,
                message: "This email address is already registered."
            });
        }

        console.error("Registration Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Registration failed. Please try again."
        });
    }
});

// Start server
// =====================================
// STUDENT LOGIN API
// =====================================

app.post("/api/login", async (req, res) => {

    try {

        const { email, password } = req.body;

        // Validate input
        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: "Please enter email and password."
            });
        }

        // Find student by email
        const sql = `
            SELECT
                student_id,
                student_name,
                email,
                college,
                department,
                current_year,
                current_semester,
                password_hash
            FROM students
            WHERE email = ?
        `;

        const [rows] = await db.execute(sql, [email.trim()]);

        // Check whether student exists
        if (rows.length === 0) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password."
            });
        }

        const student = rows[0];

        // Verify password
        const passwordMatch = await bcrypt.compare(
            password,
            student.password_hash
        );

        if (!passwordMatch) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password."
            });
        }
req.session.studentId = student.student_id;

req.session.save((error) => {
    if (error) {
        console.error("Session Save Error:", error);

        return res.status(500).json({
            success: false,
            message: "Unable to create login session."
        });
    }

    res.json({
        success: true,
        message: "Login successful!",
        student: {
            studentId: student.student_id,
            studentName: student.student_name,
            email: student.email,
            college: student.college,
            department: student.department,
            year: student.current_year,
            semester: student.current_semester
        }
    });
});
        // Successful login


    } catch (error) {

        console.error("Login Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Login failed. Please try again."
        });

    }

});

// Verify whether the student has an active login session
app.get("/api/me", requireAuth, async (req, res) => {
    try {
       

        const sql = `
            SELECT
                student_id,
                student_name,
                email,
                college,
                department,
                current_year,
                current_semester
            FROM students
            WHERE student_id = ?
        `;

        const [rows] = await db.execute(
            sql,
            [req.session.studentId]
        );

        if (rows.length === 0) {
            return req.session.destroy(() => {
                res.status(401).json({
                    success: false,
                    message: "Student account not found."
                });
            });
        }

        const student = rows[0];

        res.json({
            success: true,
            student: {
                studentId: student.student_id,
                studentName: student.student_name,
                email: student.email,
                college: student.college,
                department: student.department,
                year: student.current_year,
                semester: student.current_semester
            }
        });

    } catch (error) {
        console.error("Session Verification Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to verify login session."
        });
    }
});

app.post("/api/logout", (req, res) => {
    req.session.destroy((error) => {
        if (error) {
            console.error("Logout Error:", error);

            return res.status(500).json({
                success: false,
                message: "Unable to log out. Please try again."
            });
        }

        res.clearCookie("careerpilot.sid", {
            httpOnly: true,
            secure: false,
            sameSite: "lax"
        });

        res.json({
            success: true,
            message: "Logout successful!"
        });
    });
});

// GET Subjects API
app.get("/api/subjects", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;
console.log("GET Subjects - Student ID:", studentId);
        const sql = `
            SELECT
                subject_id,
                semester,
                subject_name,
                subject_code,
                credits,
                syllabus,
                created_at
            FROM subjects
            WHERE student_id = ?
            ORDER BY semester ASC, subject_name ASC
        `;

        const [rows] = await db.execute(sql, [studentId]);

        res.json({
            success: true,
            subjects: rows
        });

    } catch (error) {
        console.error("Fetch Subjects Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to retrieve subjects."
        });
    }
});


// POST Subjects API
app.post("/api/subjects", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;

        const {
            semester,
            subjectName,
            subjectCode,
            credits,
            syllabus
        } = req.body;

        // Validate subject name
        if (!subjectName || !subjectName.trim()) {
            return res.status(400).json({
                success: false,
                message: "Subject name is required."
            });
        }

        // Validate semester
        const semesterNumber = Number(semester);

        if (!Number.isInteger(semesterNumber) ||
            semesterNumber < 1 || semesterNumber > 8) {
            return res.status(400).json({
                success: false,
                message: "Semester must be between 1 and 8."
            });
        }

        // Validate credits
        const creditsNumber = Number(credits);

        if (!Number.isInteger(creditsNumber) ||
            creditsNumber < 1 || creditsNumber > 10) {
            return res.status(400).json({
                success: false,
                message: "Credits must be between 1 and 10."
            });
        }

        const sql = `
            INSERT INTO subjects
            (student_id, semester, subject_name, subject_code, credits, syllabus)
            VALUES (?, ?, ?, ?, ?, ?)
        `;

        const [result] = await db.execute(sql, [
            studentId,
            semesterNumber,
            subjectName.trim(),
            subjectCode ? subjectCode.trim() : null,
            creditsNumber,
            syllabus ? syllabus.trim() : null
        ]);

        res.status(201).json({
            success: true,
            message: "Subject added successfully!",
            subjectId: result.insertId
        });

    } catch (error) {
        console.error("Add Subject Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to add subject."
        });
    }
});


// PUT Subjects API
app.put("/api/subjects/:id", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;
        const subjectId = Number(req.params.id);

        const {
            semester,
            subjectName,
            subjectCode,
            credits,
            syllabus
        } = req.body;

        // Validate subject ID
        if (!Number.isInteger(subjectId) || subjectId <= 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid subject ID."
            });
        }

        // Validate subject name
        if (!subjectName || !subjectName.trim()) {
            return res.status(400).json({
                success: false,
                message: "Subject name is required."
            });
        }

        // Validate semester
        const semesterNumber = Number(semester);

        if (!Number.isInteger(semesterNumber) ||
            semesterNumber < 1 || semesterNumber > 8) {
            return res.status(400).json({
                success: false,
                message: "Semester must be between 1 and 8."
            });
        }

        // Validate credits
        const creditsNumber = Number(credits);

        if (!Number.isInteger(creditsNumber) ||
            creditsNumber < 1 || creditsNumber > 10) {
            return res.status(400).json({
                success: false,
                message: "Credits must be between 1 and 10."
            });
        }

        // Check whether the subject belongs to this student
        const checkSql = `
            SELECT subject_id
            FROM subjects
            WHERE subject_id = ?
              AND student_id = ?
        `;

        const [existingSubjects] = await db.execute(
            checkSql,
            [subjectId, studentId]
        );

        if (existingSubjects.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Subject not found."
            });
        }

        // Update the subject
        const updateSql = `
            UPDATE subjects
            SET semester = ?,
                subject_name = ?,
                subject_code = ?,
                credits = ?,
                syllabus = ?
            WHERE subject_id = ?
              AND student_id = ?
        `;

        await db.execute(updateSql, [
            semesterNumber,
            subjectName.trim(),
            subjectCode ? subjectCode.trim() : null,
            creditsNumber,
            syllabus ? syllabus.trim() : null,
            subjectId,
            studentId
        ]);

        res.json({
            success: true,
            message: "Subject updated successfully!"
        });

    } catch (error) {
        console.error("Update Subject Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to update subject."
        });
    }
});

// DELETE Subjects API
app.delete("/api/subjects/:id", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;
        const subjectId = Number(req.params.id);

        // Validate subject ID
        if (!Number.isInteger(subjectId) || subjectId <= 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid subject ID."
            });
        }

        // Delete only the subject belonging to this student
        const sql = `
            DELETE FROM subjects
            WHERE subject_id = ?
              AND student_id = ?
        `;

        const [result] = await db.execute(sql, [
            subjectId,
            studentId
        ]);

        // Check whether a subject was deleted
        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Subject not found."
            });
        }

        res.json({
            success: true,
            message: "Subject deleted successfully!"
        });

    } catch (error) {
        console.error("Delete Subject Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to delete subject."
        });
    }
});

// =====================================
// STUDENT SKILLS APIs
// =====================================

// GET Student Skills API
app.get("/api/skills", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;

        const sql = `
            SELECT
                technical_skills,
                programming_level,
                web_level,
                database_level,
                interests,
                career_goal,
                updated_at
            FROM student_skills
            WHERE student_id = ?
        `;

        const [rows] = await db.execute(sql, [studentId]);

        // No skill profile exists yet
        if (rows.length === 0) {
            return res.json({
                success: true,
                skillProfile: null
            });
        }

        const profile = rows[0];

        res.json({
            success: true,
            skillProfile: {
                technicalSkills:
                    typeof profile.technical_skills === "string"
                        ? JSON.parse(profile.technical_skills)
                        : profile.technical_skills,

                proficiency: {
                    programming: profile.programming_level,
                    webDevelopment: profile.web_level,
                    database: profile.database_level
                },

                interests:
                    typeof profile.interests === "string"
                        ? JSON.parse(profile.interests)
                        : profile.interests,

                careerGoal: profile.career_goal,
                updatedAt: profile.updated_at
            }
        });

    } catch (error) {
        console.error("Fetch Skills Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to retrieve skill profile."
        });
    }
});


// POST Student Skills API
app.post("/api/skills", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;

        const {
            technicalSkills,
            proficiency,
            interests,
            careerGoal
        } = req.body;

        // Validate technical skills
        const validSkills = [
            "C", "C++", "Java", "Python",
            "HTML", "CSS", "JavaScript", "SQL"
        ];

        if (
            !Array.isArray(technicalSkills) ||
            technicalSkills.length === 0 ||
            !technicalSkills.every(skill => validSkills.includes(skill))
        ) {
            return res.status(400).json({
                success: false,
                message: "Please select valid technical skills."
            });
        }

        // Validate areas of interest
        const validInterests = [
            "Artificial Intelligence",
            "Machine Learning",
            "Web Development",
            "Cloud Computing",
            "Cybersecurity",
            "Data Science",
            "Mobile App Development"
        ];

        if (
            !Array.isArray(interests) ||
            interests.length === 0 ||
            !interests.every(item => validInterests.includes(item))
        ) {
            return res.status(400).json({
                success: false,
                message: "Please select valid areas of interest."
            });
        }

        // Validate proficiency levels
        const validLevels = [
            "Beginner",
            "Intermediate",
            "Advanced"
        ];

        if (
            !proficiency ||
            !validLevels.includes(proficiency.programming) ||
            !validLevels.includes(proficiency.webDevelopment) ||
            !validLevels.includes(proficiency.database)
        ) {
            return res.status(400).json({
                success: false,
                message: "Please select valid proficiency levels."
            });
        }

        // Validate career goal
        const validCareerGoals = [
            "Software Developer",
            "AI Engineer",
            "Data Scientist",
            "Cloud Engineer",
            "Cybersecurity Analyst",
            "Web Developer"
        ];

        if (!validCareerGoals.includes(careerGoal)) {
            return res.status(400).json({
                success: false,
                message: "Please select a valid career goal."
            });
        }

        // Insert a new profile or update the existing profile
        const sql = `
            INSERT INTO student_skills
            (
                student_id,
                technical_skills,
                programming_level,
                web_level,
                database_level,
                interests,
                career_goal
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                technical_skills = VALUES(technical_skills),
                programming_level = VALUES(programming_level),
                web_level = VALUES(web_level),
                database_level = VALUES(database_level),
                interests = VALUES(interests),
                career_goal = VALUES(career_goal)
        `;

        await db.execute(sql, [
            studentId,
            JSON.stringify(technicalSkills),
            proficiency.programming,
            proficiency.webDevelopment,
            proficiency.database,
            JSON.stringify(interests),
            careerGoal
        ]);

        res.json({
            success: true,
            message: "Skill profile saved successfully!"
        });

    } catch (error) {
        console.error("Save Skills Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to save skill profile."
        });
    }
});

// GET Timetable API
app.get("/api/timetable", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;

        const sql = `
            SELECT
                timetable_id,
                subject_name,
                day_of_week,
                start_time,
                end_time,
                room_number,
                created_at
            FROM timetable
            WHERE student_id = ?
            ORDER BY
                FIELD(
                    day_of_week,
                    'Monday',
                    'Tuesday',
                    'Wednesday',
                    'Thursday',
                    'Friday',
                    'Saturday',
                    'Sunday'
                ),
                start_time ASC
        `;

        const [rows] = await db.execute(sql, [studentId]);

        res.json({
            success: true,
            timetable: rows
        });

    } catch (error) {
        console.error("Fetch Timetable Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to retrieve timetable."
        });
    }
});
// =====================================
// GET AI MENTOR STUDENT CONTEXT API
// =====================================

app.get("/api/mentor/context", requireAuth, async (req, res) => {

    try {

        const studentId = req.session.studentId;

        // Get Student Information
        const [studentRows] = await db.execute(
            `SELECT
                student_name,
                department,
                current_year,
                current_semester
             FROM students
             WHERE student_id = ?`,
            [studentId]
        );

        if (studentRows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Student profile not found."
            });
        }

        const student = studentRows[0];

        // Get Current Semester Subjects
        const [subjects] = await db.execute(
            `SELECT
                subject_name,
                subject_code,
                semester,
                credits,
                syllabus
             FROM subjects
             WHERE student_id = ?
             AND semester = ?
             ORDER BY subject_name`,
            [studentId, student.current_semester]
        );

        // Get Pending Assignments
        const [pendingAssignments] = await db.execute(
            `SELECT
                assignment_title,
                subject_name,
                description,
                due_date,
                status
             FROM assignments
             WHERE student_id = ?
             AND status = 'Pending'
             ORDER BY due_date ASC`,
            [studentId]
        );

        // Get Upcoming Examinations
        const [upcomingExaminations] = await db.execute(
            `SELECT
                examination_name,
                subject_name,
                exam_date,
                start_time,
                end_time
             FROM examinations
             WHERE student_id = ?
             AND exam_date >= CURDATE()
             ORDER BY exam_date ASC`,
            [studentId]
        );

        // Get Student Skill Profile
        const [skillRows] = await db.execute(
            `SELECT
                technical_skills,
                programming_level,
                web_level,
                database_level,
                interests,
                career_goal
             FROM student_skills
             WHERE student_id = ?`,
            [studentId]
        );

        let skillProfile = skillRows.length > 0
            ? skillRows[0]
            : null;

        // Handle JSON fields
        if (skillProfile) {

            if (typeof skillProfile.technical_skills === "string") {
                skillProfile.technical_skills =
                    JSON.parse(skillProfile.technical_skills);
            }

            if (typeof skillProfile.interests === "string") {
                skillProfile.interests =
                    JSON.parse(skillProfile.interests);
            }
        }

        // Return Combined Student Context
        res.json({
            success: true,

            student: student,

            subjects: subjects,

            pendingAssignments: pendingAssignments,

            upcomingExaminations: upcomingExaminations,

            skillProfile: skillProfile
        });

    } catch (error) {

        console.error(
            "Fetch AI Mentor Context Error:",
            error.message
        );

        res.status(500).json({
            success: false,
            message: "Unable to retrieve student information for AI Mentor."
        });

    }

});
// POST Timetable API
app.post("/api/timetable", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;

        const {
            subjectName,
            dayOfWeek,
            startTime,
            endTime,
            roomNumber
        } = req.body;

        // Validate required fields
        if (
            !subjectName || !subjectName.trim() ||
            !dayOfWeek ||
            !startTime ||
            !endTime
        ) {
            return res.status(400).json({
                success: false,
                message: "Subject, day, start time and end time are required."
            });
        }

        // Validate day of the week
        const validDays = [
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Sunday"
        ];

        if (!validDays.includes(dayOfWeek)) {
            return res.status(400).json({
                success: false,
                message: "Invalid day of the week."
            });
        }

        // Validate time format (HH:MM)
        const timePattern = /^([01]\d|2[0-3]):[0-5]\d$/;

        if (
            !timePattern.test(startTime) ||
            !timePattern.test(endTime)
        ) {
            return res.status(400).json({
                success: false,
                message: "Enter time in HH:MM format."
            });
        }

        // Insert timetable record
        const sql = `
            INSERT INTO timetable
            (
                student_id,
                subject_name,
                day_of_week,
                start_time,
                end_time,
                room_number
            )
            VALUES (?, ?, ?, ?, ?, ?)
        `;

        const [result] = await db.execute(sql, [
            studentId,
            subjectName.trim(),
            dayOfWeek,
            startTime,
            endTime,
            roomNumber || null
        ]);

        res.status(201).json({
            success: true,
            message: "Timetable entry added successfully!",
            timetableId: result.insertId
        });

    } catch (error) {
        console.error("Add Timetable Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to add timetable entry."
        });
    }
});
// PUT Timetable API
app.put("/api/timetable/:id", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;
        const timetableId = Number(req.params.id);

        const {
            subjectName,
            dayOfWeek,
            startTime,
            endTime,
            roomNumber
        } = req.body;

        if (!Number.isInteger(timetableId) || timetableId <= 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid timetable ID."
            });
        }

        if (
            !subjectName || !subjectName.trim() ||
            !dayOfWeek || !startTime || !endTime
        ) {
            return res.status(400).json({
                success: false,
                message: "All required timetable fields must be provided."
            });
        }

        const validDays = [
            "Monday", "Tuesday", "Wednesday",
            "Thursday", "Friday", "Saturday", "Sunday"
        ];

        const timePattern = /^([01]\d|2[0-3]):[0-5]\d$/;

        if (
            !validDays.includes(dayOfWeek) ||
            !timePattern.test(startTime) ||
            !timePattern.test(endTime)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid day or time format."
            });
        }

        // Check whether this timetable belongs to the logged-in student
        const checkSql = `
            SELECT timetable_id
            FROM timetable
            WHERE timetable_id = ?
              AND student_id = ?
        `;

        const [existingRecords] = await db.execute(
            checkSql,
            [timetableId, studentId]
        );

        if (existingRecords.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Timetable entry not found."
            });
        }

        // Update timetable record
        const updateSql = `
            UPDATE timetable
            SET subject_name = ?,
                day_of_week = ?,
                start_time = ?,
                end_time = ?,
                room_number = ?
            WHERE timetable_id = ?
              AND student_id = ?
        `;

        await db.execute(updateSql, [
            subjectName.trim(),
            dayOfWeek,
            startTime,
            endTime,
            roomNumber || null,
            timetableId,
            studentId
        ]);

        res.json({
            success: true,
            message: "Timetable entry updated successfully!"
        });

    } catch (error) {
        console.error("Update Timetable Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to update timetable entry."
        });
    }
});
// DELETE Timetable API
app.delete("/api/timetable/:id", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;
        const timetableId = Number(req.params.id);

        // Validate timetable ID
        if (!Number.isInteger(timetableId) || timetableId <= 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid timetable ID."
            });
        }

        // Delete only the logged-in student's record
        const sql = `
            DELETE FROM timetable
            WHERE timetable_id = ?
              AND student_id = ?
        `;

        const [result] = await db.execute(sql, [
            timetableId,
            studentId
        ]);

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Timetable entry not found."
            });
        }

        res.json({
            success: true,
            message: "Timetable entry deleted successfully!"
        });

    } catch (error) {
        console.error("Delete Timetable Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to delete timetable entry."
        });
    }
});// GET Assignments API
app.get("/api/assignments", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;

        const sql = `
            SELECT
                assignment_id,
                assignment_title,
                subject_name,
                description,
                due_date,
                status,
                created_at
            FROM assignments
            WHERE student_id = ?
            ORDER BY due_date ASC
        `;

        const [rows] = await db.execute(sql, [studentId]);

        res.json({
            success: true,
            assignments: rows
        });

    } catch (error) {
        console.error("Fetch Assignments Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to retrieve assignments."
        });
    }
});
// POST Assignments API
app.post("/api/assignments", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;

        const {
            assignmentTitle,
            subjectName,
            description,
            dueDate,
            status
        } = req.body;

        // Validate required fields
        if (
            !assignmentTitle || !assignmentTitle.trim() ||
            !subjectName || !subjectName.trim()
        ) {
            return res.status(400).json({
                success: false,
                message: "Assignment title and subject are required."
            });
        }

        // Validate assignment status
        const validStatuses = ["Pending", "Completed"];

        if (status && !validStatuses.includes(status)) {
            return res.status(400).json({
                success: false,
                message: "Invalid assignment status."
            });
        }

        // Insert assignment into MySQL
        const sql = `
            INSERT INTO assignments
            (
                student_id,
                assignment_title,
                subject_name,
                description,
                due_date,
                status
            )
            VALUES (?, ?, ?, ?, ?, ?)
        `;

        const [result] = await db.execute(sql, [
            studentId,
            assignmentTitle.trim(),
            subjectName.trim(),
            description || null,
            dueDate || null,
            status || "Pending"
        ]);

        res.status(201).json({
            success: true,
            message: "Assignment added successfully!",
            assignmentId: result.insertId
        });

    } catch (error) {
        console.error("Add Assignment Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to add assignment."
        });
    }
});
// PUT Assignments API
app.put("/api/assignments/:id", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;
        const assignmentId = Number(req.params.id);

        const {
            assignmentTitle,
            subjectName,
            description,
            dueDate,
            status
        } = req.body;

        // Validate assignment ID
        if (!Number.isInteger(assignmentId) || assignmentId <= 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid assignment ID."
            });
        }

        // Validate required fields
        if (
            !assignmentTitle || !assignmentTitle.trim() ||
            !subjectName || !subjectName.trim()
        ) {
            return res.status(400).json({
                success: false,
                message: "Assignment title and subject are required."
            });
        }

        // Validate status
        const validStatuses = ["Pending", "Completed"];

        if (!validStatuses.includes(status)) {
            return res.status(400).json({
                success: false,
                message: "Invalid assignment status."
            });
        }

        // Check assignment ownership
        const checkSql = `
            SELECT assignment_id
            FROM assignments
            WHERE assignment_id = ?
              AND student_id = ?
        `;

        const [existingRecords] = await db.execute(
            checkSql,
            [assignmentId, studentId]
        );

        if (existingRecords.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Assignment not found."
            });
        }

        // Update assignment
        const updateSql = `
            UPDATE assignments
            SET assignment_title = ?,
                subject_name = ?,
                description = ?,
                due_date = ?,
                status = ?
            WHERE assignment_id = ?
              AND student_id = ?
        `;

        await db.execute(updateSql, [
            assignmentTitle.trim(),
            subjectName.trim(),
            description || null,
            dueDate || null,
            status,
            assignmentId,
            studentId
        ]);

        res.json({
            success: true,
            message: "Assignment updated successfully!"
        });

    } catch (error) {
        console.error("Update Assignment Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to update assignment."
        });
    }
});
// DELETE Assignments API
app.delete("/api/assignments/:id", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;
        const assignmentId = Number(req.params.id);

        // Validate assignment ID
        if (!Number.isInteger(assignmentId) || assignmentId <= 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid assignment ID."
            });
        }

        // Delete only the logged-in student's assignment
        const sql = `
            DELETE FROM assignments
            WHERE assignment_id = ?
              AND student_id = ?
        `;

        const [result] = await db.execute(sql, [
            assignmentId,
            studentId
        ]);

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Assignment not found."
            });
        }

        res.json({
            success: true,
            message: "Assignment deleted successfully!"
        });

    } catch (error) {
        console.error("Delete Assignment Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to delete assignment."
        });
    }
});
// GET Examinations API
app.get("/api/examinations", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;

        const sql = `
            SELECT
                examination_id,
                examination_name,
                subject_name,
                exam_date,
                start_time,
                end_time,
                room_number,
                created_at
            FROM examinations
            WHERE student_id = ?
            ORDER BY exam_date ASC, start_time ASC
        `;

        const [rows] = await db.execute(sql, [studentId]);

        res.json({
            success: true,
            examinations: rows
        });

    } catch (error) {
        console.error("Fetch Examinations Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to retrieve examinations."
        });
    }
});
// POST Examinations API
app.post("/api/examinations", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;

        const {
            examinationName,
            subjectName,
            examDate,
            startTime,
            endTime,
            roomNumber
        } = req.body;

        // Validate required fields
        if (
            !examinationName || !examinationName.trim() ||
            !subjectName || !subjectName.trim() ||
            !examDate
        ) {
            return res.status(400).json({
                success: false,
                message: "Examination name, subject and exam date are required."
            });
        }

        // Validate date format (YYYY-MM-DD)
        const datePattern = /^\d{4}-\d{2}-\d{2}$/;

        if (!datePattern.test(examDate)) {
            return res.status(400).json({
                success: false,
                message: "Enter the exam date in YYYY-MM-DD format."
            });
        }

        // Validate optional time fields
        const timePattern = /^([01]\d|2[0-3]):[0-5]\d$/;

        if (
            (startTime && !timePattern.test(startTime)) ||
            (endTime && !timePattern.test(endTime))
        ) {
            return res.status(400).json({
                success: false,
                message: "Enter time in HH:MM format."
            });
        }

        // Insert examination into MySQL
        const sql = `
            INSERT INTO examinations
            (
                student_id,
                examination_name,
                subject_name,
                exam_date,
                start_time,
                end_time,
                room_number
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

        const [result] = await db.execute(sql, [
            studentId,
            examinationName.trim(),
            subjectName.trim(),
            examDate,
            startTime || null,
            endTime || null,
            roomNumber || null
        ]);

        res.status(201).json({
            success: true,
            message: "Examination added successfully!",
            examinationId: result.insertId
        });

    } catch (error) {
        console.error("Add Examination Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to add examination."
        });
    }
});
// PUT Examinations API
app.put("/api/examinations/:id", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;
        const examinationId = Number(req.params.id);

        const {
            examinationName,
            subjectName,
            examDate,
            startTime,
            endTime,
            roomNumber
        } = req.body;

        // Validate examination ID
        if (!Number.isInteger(examinationId) || examinationId <= 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid examination ID."
            });
        }

        // Validate required fields
        if (
            !examinationName || !examinationName.trim() ||
            !subjectName || !subjectName.trim() ||
            !examDate
        ) {
            return res.status(400).json({
                success: false,
                message: "Examination name, subject and exam date are required."
            });
        }

        // Validate date format
        const datePattern = /^\d{4}-\d{2}-\d{2}$/;

        if (!datePattern.test(examDate)) {
            return res.status(400).json({
                success: false,
                message: "Enter date in YYYY-MM-DD format."
            });
        }

        // Validate optional time fields
        const timePattern = /^([01]\d|2[0-3]):[0-5]\d$/;

        if (
            (startTime && !timePattern.test(startTime)) ||
            (endTime && !timePattern.test(endTime))
        ) {
            return res.status(400).json({
                success: false,
                message: "Enter time in HH:MM format."
            });
        }

        // Check examination ownership
        const checkSql = `
            SELECT examination_id
            FROM examinations
            WHERE examination_id = ?
              AND student_id = ?
        `;

        const [existingRecords] = await db.execute(
            checkSql,
            [examinationId, studentId]
        );

        if (existingRecords.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Examination not found."
            });
        }

        // Update examination
        const updateSql = `
            UPDATE examinations
            SET examination_name = ?,
                subject_name = ?,
                exam_date = ?,
                start_time = ?,
                end_time = ?,
                room_number = ?
            WHERE examination_id = ?
              AND student_id = ?
        `;

        await db.execute(updateSql, [
            examinationName.trim(),
            subjectName.trim(),
            examDate,
            startTime || null,
            endTime || null,
            roomNumber || null,
            examinationId,
            studentId
        ]);

        res.json({
            success: true,
            message: "Examination updated successfully!"
        });

    } catch (error) {
        console.error("Update Examination Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to update examination."
        });
    }
});
// DELETE Examinations API
app.delete("/api/examinations/:id", requireAuth, async (req, res) => {
    try {
        const studentId = req.session.studentId;
        const examinationId = Number(req.params.id);

        // Validate examination ID
        if (!Number.isInteger(examinationId) || examinationId <= 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid examination ID."
            });
        }

        // Delete only the logged-in student's examination
        const sql = `
            DELETE FROM examinations
            WHERE examination_id = ?
              AND student_id = ?
        `;

        const [result] = await db.execute(sql, [
            examinationId,
            studentId
        ]);

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Examination not found."
            });
        }

        res.json({
            success: true,
            message: "Examination deleted successfully!"
        });

    } catch (error) {
        console.error("Delete Examination Error:", error.message);

        res.status(500).json({
            success: false,
            message: "Unable to delete examination."
        });
    }
});
// Test database connection
testDatabaseConnection();
app.listen(PORT, () => {
    console.log(`CareerPilot AI server running on port ${PORT}`);
});