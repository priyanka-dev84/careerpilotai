async function testLoginAPI() {

    try {

        const response = await fetch(
            "http://localhost:3000/api/login",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    email: "teststudent@example.com",
                    password: "TestPass123!"
                })
            }
        );

        const data = await response.json();

        console.log("Login API Response:", data);

    } catch (error) {

        console.error("Login API Test Failed:", error);

    }

}

testLoginAPI();