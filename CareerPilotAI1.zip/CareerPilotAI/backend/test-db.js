
const { testDatabaseConnection } = require("./db");

// Test MySQL connection
testDatabaseConnection();
