
// ======================================
// CAREERPILOT AI - ACADEMIC MANAGEMENT
// ======================================

// Backend API URL
const ACADEMIC_API = window.CAREERPILOT_API_BASE;

// Store subjects retrieved from backend
let academicSubjects = [];

// Safely display text entered by students
function escapeAcademicText(value) {
    return String(value ?? "").replace(/[&<>"']/g, function(char) {
        const entities = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };

        return entities[char];
    });
}

// Display subjects in the table
function displaySubjects() {
    const subjectList = document.getElementById("subjectList");

    if (!subjectList) return;

    if (academicSubjects.length === 0) {
        subjectList.innerHTML = `
            <tr>
                <td colspan="6" class="empty-message">
                    No subjects added yet.
                </td>
            </tr>
        `;
        return;
    }

    subjectList.innerHTML = academicSubjects.map(function(subject) {
        return `
            <tr>
                <td>${escapeAcademicText(subject.semester)}</td>
                <td>${escapeAcademicText(subject.subject_name)}</td>
                <td>${escapeAcademicText(subject.subject_code || "N/A")}</td>
                <td>${escapeAcademicText(subject.credits)}</td>
                <td>${escapeAcademicText(subject.syllabus || "Not entered")}</td>
                <td>
                    <button type="button"
                        onclick="deleteSubject(${Number(subject.subject_id)})">
                        Delete
                    </button>
                </td>
            </tr>
        `;
    }).join("");
}

// Retrieve subjects from backend
async function loadSubjects() {
    try {
        const response = await fetch(`${ACADEMIC_API}/subjects`, {
            method: "GET",
            credentials: "include"
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.message || "Unable to load subjects.");
        }

        academicSubjects = data.subjects;
        displaySubjects();

    } catch (error) {
        console.error("Load Subjects Error:", error);

        const subjectList = document.getElementById("subjectList");

        if (subjectList) {
            subjectList.innerHTML = `
                <tr>
                    <td colspan="6">
                        Unable to load subjects. Please log in again
                        or refresh the page.
                    </td>
                </tr>
            `;
        }
    }
}

// Delete Timetable Entry
async function deleteTimetable(timetableId) {
    const confirmDelete = confirm(
        "Are you sure you want to delete this timetable entry?"
    );

    if (!confirmDelete) {
        return;
    }

    try {
        const response = await fetch(
            `${ACADEMIC_API}/timetable/${timetableId}`,
            {
                method: "DELETE",
                credentials: "include"
            }
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
            alert(data.message || "Unable to delete timetable entry.");
            return;
        }

        alert("Timetable entry deleted successfully!");

        await loadTimetable();

    } catch (error) {
        console.error("Delete Timetable Error:", error);
        alert("Unable to connect to the server.");
    }
}

// Add Subject Form
const subjectForm = document.getElementById("subjectForm");

if (subjectForm) {
    subjectForm.addEventListener("submit", async function(event) {
        event.preventDefault();

        const subjectData = {
            semester: document.getElementById("subjectSemester").value,
            subjectName: document.getElementById("subjectName").value.trim(),
            subjectCode: document.getElementById("subjectCode").value.trim(),
            credits: document.getElementById("subjectCredits").value,
            syllabus: document.getElementById("subjectSyllabus").value.trim()
        };

        try {
            const response = await fetch(`${ACADEMIC_API}/subjects`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                credentials: "include",
                body: JSON.stringify(subjectData)
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                alert(data.message || "Unable to add subject.");
                return;
            }

            alert("Subject added successfully!");

            subjectForm.reset();

            await loadSubjects();

        } catch (error) {
            console.error("Add Subject Error:", error);
            alert("Unable to connect to the server.");
        }
    });
}
// Load academic records when the page opens
document.addEventListener("DOMContentLoaded", function() {
    loadSubjects();
    loadTimetable();
    loadAssignments();
    loadExaminations();
});

// ======================================
// TIMETABLE MANAGEMENT
// ======================================

// Store timetable entries retrieved from backend
let academicTimetable = [];
// Track timetable entry currently being edited
let editingTimetableId = null;
// Display timetable entries in the table
function displayTimetable() {
    const timetableList = document.getElementById("timetableList");

    if (!timetableList) return;

    if (academicTimetable.length === 0) {
        timetableList.innerHTML = `
            <tr>
                <td colspan="6" class="empty-message">
                    No timetable entries added yet.
                </td>
            </tr>
        `;
        return;
    }

    timetableList.innerHTML = academicTimetable.map(function(item) {
        return `
            <tr>
                <td>${escapeAcademicText(item.day_of_week)}</td>
                <td>${escapeAcademicText(item.subject_name)}</td>
                <td>${escapeAcademicText(item.start_time)}</td>
                <td>${escapeAcademicText(item.end_time)}</td>
                <td>${escapeAcademicText(item.room_number || "N/A")}</td>
                <td>
<button type="button"
    onclick="editTimetable(${Number(item.timetable_id)})">
    Edit
</button>

<button type="button"
    onclick="deleteTimetable(${Number(item.timetable_id)})">
    Delete
</button>
                </td>
            </tr>
        `;
    }).join("");
}

// Edit Timetable Entry
function editTimetable(timetableId) {
    const timetableEntry = academicTimetable.find(function(item) {
        return Number(item.timetable_id) === Number(timetableId);
    });

    if (!timetableEntry) {
        alert("Timetable entry not found.");
        return;
    }

    editingTimetableId = timetableId;
console.log("Editing Timetable ID:", editingTimetableId);
    document.getElementById("classDay").value =
        timetableEntry.day_of_week;

    document.getElementById("classSubject").value =
        timetableEntry.subject_name;

    document.getElementById("classStart").value =
        timetableEntry.start_time.substring(0, 5);

    document.getElementById("classEnd").value =
        timetableEntry.end_time.substring(0, 5);

    document.getElementById("classroom").value =
        timetableEntry.room_number || "";

    // Change the form button text
    const submitButton = document.querySelector(
        "#timetableForm button[type='submit']"
    );

    if (submitButton) {
        submitButton.textContent = "Update Timetable";
    }

    // Bring the form into view
    document.getElementById("timetableForm").scrollIntoView({
        behavior: "smooth",
        block: "center"
    });
}

// Retrieve timetable entries from backend
async function loadTimetable() {
    try {
        const response = await fetch(`${ACADEMIC_API}/timetable`, {
            method: "GET",
            credentials: "include"
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.message || "Unable to load timetable.");
        }

        academicTimetable = data.timetable;
        displayTimetable();

    } catch (error) {
        console.error("Load Timetable Error:", error);

        const timetableList = document.getElementById("timetableList");

        if (timetableList) {
            timetableList.innerHTML = `
                <tr>
                    <td colspan="6">
                        Unable to load timetable. Please log in again
                        or refresh the page.
                    </td>
                </tr>
            `;
        }
    }
}


// Add / Update Timetable Form
const timetableForm = document.getElementById("timetableForm");

if (timetableForm) {
    timetableForm.addEventListener("submit", async function(event) {
        event.preventDefault();

        const timetableData = {
            dayOfWeek: document.getElementById("classDay").value,
            subjectName: document.getElementById("classSubject").value.trim(),
            startTime: document.getElementById("classStart").value,
            endTime: document.getElementById("classEnd").value,
            roomNumber: document.getElementById("classroom").value.trim()
        };

        const isEditing = editingTimetableId !== null;
console.log("Is Editing:", isEditing);
console.log("Timetable ID:", editingTimetableId);
        const apiUrl = isEditing
            ? `${ACADEMIC_API}/timetable/${editingTimetableId}`
            : `${ACADEMIC_API}/timetable`;

        const requestMethod = isEditing ? "PUT" : "POST";

        try {
            const response = await fetch(apiUrl, {
                method: requestMethod,
                headers: {
                    "Content-Type": "application/json"
                },
                credentials: "include",
                body: JSON.stringify(timetableData)
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                alert(data.message || "Unable to save timetable entry.");
                return;
            }

            alert(isEditing
                ? "Timetable updated successfully!"
                : "Timetable entry added successfully!"
            );

            timetableForm.reset();

            editingTimetableId = null;

            const submitButton = timetableForm.querySelector(
                "button[type='submit']"
            );

            if (submitButton) {
                submitButton.textContent = "Add Timetable";
            }

            await loadTimetable();

        } catch (error) {
            console.error("Save Timetable Error:", error);
            alert("Unable to connect to the server.");
        }
    });
}

// ======================================
// ASSIGNMENT MANAGEMENT
// ======================================

// Store assignments retrieved from backend
let academicAssignments = [];

// Display assignments in the table
function displayAssignments() {
    const assignmentList = document.getElementById("assignmentList");

    if (!assignmentList) return;

    if (academicAssignments.length === 0) {
        assignmentList.innerHTML = `
            <tr>
                <td colspan="5" class="empty-message">
                    No assignments added yet.
                </td>
            </tr>
        `;
        return;
    }

    assignmentList.innerHTML = academicAssignments.map(function(item) {
        return `
            <tr>
                <td>${escapeAcademicText(item.assignment_title)}</td>
                <td>${escapeAcademicText(item.subject_name)}</td>
                <td>${escapeAcademicText(item.due_date || "Not specified")}</td>
                <td>${escapeAcademicText(item.status)}</td>
                <td>
                    <button type="button"
                        onclick="editAssignment(${Number(item.assignment_id)})">
                        Edit
                    </button>

                    <button type="button"
                        onclick="deleteAssignment(${Number(item.assignment_id)})">
                        Delete
                    </button>
                </td>
            </tr>
        `;
    }).join("");
}

// Retrieve assignments from backend
async function loadAssignments() {
    try {
        const response = await fetch(`${ACADEMIC_API}/assignments`, {
            method: "GET",
            credentials: "include"
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.message || "Unable to load assignments.");
        }

        academicAssignments = data.assignments;
        displayAssignments();

    } catch (error) {
        console.error("Load Assignments Error:", error);

        const assignmentList = document.getElementById("assignmentList");

        if (assignmentList) {
            assignmentList.innerHTML = `
                <tr>
                    <td colspan="5">
                        Unable to load assignments. Please log in again
                        or refresh the page.
                    </td>
                </tr>
            `;
        }
    }
}

 // Delete Assignment
async function deleteAssignment(assignmentId) {
    const confirmDelete = confirm(
        "Are you sure you want to delete this assignment?"
    );

    if (!confirmDelete) {
        return;
    }

    try {
        const response = await fetch(
            `${ACADEMIC_API}/assignments/${assignmentId}`,
            {
                method: "DELETE",
                credentials: "include"
            }
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
            alert(data.message || "Unable to delete assignment.");
            return;
        }

        alert("Assignment deleted successfully!");

        await loadAssignments();

    } catch (error) {
        console.error("Delete Assignment Error:", error);
        alert("Unable to connect to the server.");
    }
}
window.deleteAssignment = deleteAssignment;

// Add / Update Assignment Form
const assignmentForm = document.getElementById("assignmentForm");

if (assignmentForm) {
    assignmentForm.addEventListener("submit", async function(event) {
        event.preventDefault();

        const assignmentData = {
            assignmentTitle: document.getElementById("assignmentTitle").value.trim(),
            subjectName: document.getElementById("assignmentSubject").value.trim(),
            dueDate: document.getElementById("assignmentDate").value,
            status: "Pending"
        };

        const isEditing = editingAssignmentId !== null;

        const apiUrl = isEditing
            ? `${ACADEMIC_API}/assignments/${editingAssignmentId}`
            : `${ACADEMIC_API}/assignments`;

        const requestMethod = isEditing ? "PUT" : "POST";

        try {
            const response = await fetch(apiUrl, {
                method: requestMethod,
                headers: {
                    "Content-Type": "application/json"
                },
                credentials: "include",
                body: JSON.stringify(assignmentData)
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                alert(data.message || "Unable to save assignment.");
                return;
            }

            alert(isEditing
                ? "Assignment updated successfully!"
                : "Assignment added successfully!"
            );

            assignmentForm.reset();

            editingAssignmentId = null;

            await loadAssignments();

        } catch (error) {
            console.error("Save Assignment Error:", error);
            alert("Unable to connect to the server.");
        }
    });
}
// Edit Assignment
let editingAssignmentId = null;

function editAssignment(assignmentId) {
    const assignment = academicAssignments.find(function(item) {
        return Number(item.assignment_id) === Number(assignmentId);
    });

    if (!assignment) {
        alert("Assignment not found.");
        return;
    }

    editingAssignmentId = assignmentId;

    document.getElementById("assignmentTitle").value =
        assignment.assignment_title;

    document.getElementById("assignmentSubject").value =
        assignment.subject_name;

    document.getElementById("assignmentDate").value =
        assignment.due_date
            ? String(assignment.due_date).substring(0, 10)
            : "";

    document.getElementById("assignmentForm").scrollIntoView({
        behavior: "smooth",
        block: "center"
    });

    console.log("Editing Assignment ID:", editingAssignmentId);
}

window.editAssignment = editAssignment;

// ======================================
// EXAMINATION MANAGEMENT
// ======================================

// Store examinations retrieved from backend
let academicExaminations = [];

// Display examinations in the table
function displayExaminations() {
    const examList = document.getElementById("examList");

    if (!examList) return;

    if (academicExaminations.length === 0) {
        examList.innerHTML = `
            <tr>
                <td colspan="4" class="empty-message">
                    No examinations added yet.
                </td>
            </tr>
        `;
        return;
    }

    examList.innerHTML = academicExaminations.map(function(item) {
        return `
            <tr>
                <td>${escapeAcademicText(item.examination_name)}</td>
                <td>${escapeAcademicText(item.subject_name)}</td>
                <td>${escapeAcademicText(item.exam_date)}</td>
                <td>
                    <button type="button"
                        onclick="editExamination(${Number(item.examination_id)})">
                        Edit
                    </button>

                    <button type="button"
                        onclick="deleteExamination(${Number(item.examination_id)})">
                        Delete
                    </button>
                </td>
            </tr>
        `;
    }).join("");
}

// Retrieve examinations from backend
async function loadExaminations() {
    try {
        const response = await fetch(`${ACADEMIC_API}/examinations`, {
            method: "GET",
            credentials: "include"
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(
                data.message || "Unable to load examinations."
            );
        }

        academicExaminations = data.examinations;
        displayExaminations();

    } catch (error) {
        console.error("Load Examinations Error:", error);

        const examList = document.getElementById("examList");

        if (examList) {
            examList.innerHTML = `
                <tr>
                    <td colspan="4">
                        Unable to load examinations. Please log in again
                        or refresh the page.
                    </td>
                </tr>
            `;
        }
    }
}

// Delete Examination
async function deleteExamination(examinationId) {
    const confirmDelete = confirm(
        "Are you sure you want to delete this examination?"
    );

    if (!confirmDelete) {
        return;
    }

    try {
        const response = await fetch(
            `${ACADEMIC_API}/examinations/${examinationId}`,
            {
                method: "DELETE",
                credentials: "include"
            }
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
            alert(data.message || "Unable to delete examination.");
            return;
        }

        alert("Examination deleted successfully!");

        await loadExaminations();

    } catch (error) {
        console.error("Delete Examination Error:", error);
        alert("Unable to connect to the server.");
    }
}

window.deleteExamination = deleteExamination;

// Edit Examination
let editingExaminationId = null;

function editExamination(examinationId) {
    const examination = academicExaminations.find(function(item) {
        return Number(item.examination_id) === Number(examinationId);
    });

    if (!examination) {
        alert("Examination not found.");
        return;
    }

    editingExaminationId = examinationId;

    document.getElementById("examName").value =
        examination.examination_name;

    document.getElementById("examSubject").value =
        examination.subject_name;

    document.getElementById("examDate").value =
        String(examination.exam_date).substring(0, 10);

    document.getElementById("examForm").scrollIntoView({
        behavior: "smooth",
        block: "center"
    });

    console.log("Editing Examination ID:", editingExaminationId);
}

window.editExamination = editExamination;


// Add / Update Examination Form
const examForm = document.getElementById("examForm");

if (examForm) {
    examForm.addEventListener("submit", async function(event) {
        event.preventDefault();

        const examinationData = {
            examinationName: document.getElementById("examName").value.trim(),
            subjectName: document.getElementById("examSubject").value.trim(),
            examDate: document.getElementById("examDate").value
        };

        const isEditing = editingExaminationId !== null;

        const apiUrl = isEditing
            ? `${ACADEMIC_API}/examinations/${editingExaminationId}`
            : `${ACADEMIC_API}/examinations`;

        const requestMethod = isEditing ? "PUT" : "POST";

        try {
            const response = await fetch(apiUrl, {
                method: requestMethod,
                headers: {
                    "Content-Type": "application/json"
                },
                credentials: "include",
                body: JSON.stringify(examinationData)
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                alert(data.message || "Unable to save examination.");
                return;
            }

            alert(isEditing
                ? "Examination updated successfully!"
                : "Examination added successfully!"
            );

            examForm.reset();

            editingExaminationId = null;

            await loadExaminations();

        } catch (error) {
            console.error("Save Examination Error:", error);
            alert("Unable to connect to the server.");
        }
    });
}
