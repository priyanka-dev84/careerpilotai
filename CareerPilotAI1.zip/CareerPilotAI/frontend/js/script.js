// =====================================
// CAREERPILOT AI - API CONFIGURATION
// =====================================

window.CAREERPILOT_API_BASE =
    (window.location.hostname === "localhost" ||
     window.location.hostname === "127.0.0.1")
        ? "http://localhost:3000/api"
        : "https://careerpilotai-y2xx.onrender.com/api";

// Student Registration

// =====================================
// STUDENT REGISTRATION - BACKEND CONNECTION
// =====================================
// STUDENT REGISTRATION
// =====================================

const registrationForm =
    document.getElementById("registrationForm");

if (registrationForm) {

    registrationForm.addEventListener("submit", async function(event) {

        event.preventDefault();

        const studentName =
            document.getElementById("studentName").value.trim();

        const email =
            document.getElementById("email").value.trim();

        const college =
            document.getElementById("college").value.trim();

        const department =
            document.getElementById("department").value;

        const year =
            document.getElementById("year").value;

        const semester =
            document.getElementById("semester").value;

        const password =
            document.getElementById("password").value;

        const confirmPassword =
            document.getElementById("confirmPassword").value;

        // Validate passwords
        if (password !== confirmPassword) {
            alert("Passwords do not match!");
            return;
        }

        // Prepare student data
        const studentData = {
            studentName: studentName,
            email: email,
            college: college,
            department: department,
            year: year,
            semester: semester,
            password: password,
            confirmPassword: confirmPassword
        };

        try {

            const response = await fetch(
                window.CAREERPILOT_API_BASE + "/student",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(studentData)
                }
            );

            const result = await response.json();

            if (response.ok && result.success) {

                alert(result.message);

                registrationForm.reset();

            } else {

                alert(result.message || "Registration failed.");

            }

        } catch (error) {

            console.error("Registration Error:", error);

            alert("Unable to connect to the backend.");

        }

    });

}
if (registrationForm) {

    registrationForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const password =
            document.getElementById("password").value;

        const confirmPassword =
            document.getElementById("confirmPassword").value;

        if (password !== confirmPassword) {

            alert("Passwords do not match!");
            return;

        }

        alert("Registration form completed successfully!");

    });

}


// =====================================
// STUDENT LOGIN
// =====================================

const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", async function(event) {

        event.preventDefault();

        const email =
            document.getElementById("loginEmail").value.trim();

        const password =
            document.getElementById("loginPassword").value;

        try {

const response = await fetch(
    window.CAREERPILOT_API_BASE + "/login",
    {
        method: "POST",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: email,
            password: password
        })
    }
);

            const result = await response.json();

            if (response.ok && result.success) {

                // Store student profile for this browser tab


                alert("Login successful! Welcome to CareerPilot AI.");

                window.location.href = "dashboard.html";

            } else {

                alert(result.message || "Invalid email or password.");

            }

        } catch (error) {

            console.error("Login Error:", error);

            alert("Unable to connect to the backend.");

        }

    });

}

// Dashboard AI Mentor Button

function showDashboardMessage() {

    alert(
        "Welcome to CareerPilot AI Mentor! " +
        "AI guidance functionality will be integrated in a later step."
    );

}
// =====================================
// LOAD DASHBOARD ACADEMIC SUMMARY
// =====================================

async function loadDashboardSummary() {

    try {
     if (!document.getElementById("dashboardTotalSubjects")) {
        return;
    }
        const [studentResponse, subjectsResponse, assignmentsResponse] =
            await Promise.all([

                fetch(window.CAREERPILOT_API_BASE + "/me", {
                    credentials: "include"
                }),

                fetch(window.CAREERPILOT_API_BASE + "/subjects", {
                    credentials: "include"
                }),

                fetch(window.CAREERPILOT_API_BASE + "/assignments", {
                    credentials: "include"
                })

            ]);

        if (
            !studentResponse.ok ||
            !subjectsResponse.ok ||
            !assignmentsResponse.ok
        ) {
            console.error("Failed to load dashboard summary.");
            return;
        }

        const studentResult = await studentResponse.json();
        const subjectsResult = await subjectsResponse.json();
        const assignmentsResult = await assignmentsResponse.json();

        if (
            !studentResult.success ||
            !subjectsResult.success ||
            !assignmentsResult.success
        ) {
            console.error("Dashboard summary data is unavailable.");
            return;
        }

        const student = studentResult.student;
        const subjects = subjectsResult.subjects;
        const assignments = assignmentsResult.assignments;

        // Count subjects for the student's current semester
        const currentSemesterSubjects = subjects.filter(subject =>
            Number(subject.semester) === Number(student.semester)
        );

        // Count pending assignments
        const pendingAssignments = assignments.filter(assignment =>
            assignment.status === "Pending"
        );

        // Update Total Subjects card
        document.getElementById("dashboardTotalSubjects").textContent =
            currentSemesterSubjects.length;

        // Update Pending Assignments card
        document.getElementById("dashboardPendingAssignments").textContent =
            pendingAssignments.length + " Pending";

        // Update Department card
        document.getElementById("dashboardDepartmentCard").textContent =
            student.department;

        console.log("Dashboard summary loaded successfully.");

    } catch (error) {

        console.error("Dashboard Summary Error:", error);

    }

}


// Load Dashboard Summary
loadDashboardSummary();

// =====================================
// LOAD DASHBOARD ASSIGNMENTS
// =====================================

async function loadDashboardAssignments() {

    const assignmentsContainer =
        document.getElementById("dashboardAssignmentsList");

    // Run only on the Dashboard page
    if (!assignmentsContainer) {
        return;
    }

    try {

        const response = await fetch(
            window.CAREERPILOT_API_BASE + "/assignments",
            {
                method: "GET",
                credentials: "include"
            }
        );

        if (!response.ok) {
            assignmentsContainer.textContent =
                "Unable to load assignments.";
            return;
        }

        const result = await response.json();

        if (!result.success) {
            assignmentsContainer.textContent =
                "Unable to retrieve assignments.";
            return;
        }

        const assignments = result.assignments;
console.log("Assignments received:", assignments);
console.log("Number of assignments:", assignments.length);

        // Show message if no assignments exist
        if (assignments.length === 0) {
            assignmentsContainer.textContent =
                "No assignments available.";
            return;
        }


// Display assignments
assignmentsContainer.innerHTML = "";

assignments.forEach(assignment => {

    const taskItem = document.createElement("div");
    taskItem.className = "task-item";

    const details = document.createElement("div");

    // Subject name
    const title = document.createElement("strong");
    title.textContent = assignment.subject_name;

    // Assignment title
    const description = document.createElement("p");
    description.textContent = assignment.assignment_title;

    // Assignment due date
    const assignmentDueDate = document.createElement("p");

    if (assignment.due_date) {

        const [year, month, day] =
            assignment.due_date.slice(0, 10).split("-");

        const formattedDueDate = new Date(
            Number(year),
            Number(month) - 1,
            Number(day)
        ).toLocaleDateString("en-IN", {
            day: "numeric",
            month: "long",
            year: "numeric"
        });

        assignmentDueDate.textContent =
            "Due: " + formattedDueDate;

    } else {

        assignmentDueDate.textContent = "Due date not set";

    }

    // Assignment status
    const status = document.createElement("span");

    status.className =
        "status " +
        (assignment.status === "Completed"
            ? "completed"
            : "pending");

    status.textContent = assignment.status;

    // Add elements to the assignment card
    details.appendChild(title);
    details.appendChild(description);
    details.appendChild(assignmentDueDate);

    taskItem.appendChild(details);
    taskItem.appendChild(status);

    assignmentsContainer.appendChild(taskItem);

});

console.log("Dashboard assignments loaded successfully.");

    } catch (error) {

        console.error("Dashboard Assignments Error:", error);

        assignmentsContainer.textContent =
            "Unable to connect to the backend.";

    }

}

// Load dashboard assignments
loadDashboardAssignments();
/* =====================================
   STUDENT SKILL ASSESSMENT FUNCTIONALITY
===================================== */


const skillsForm = document.getElementById("skillsForm");

if (skillsForm) {
    skillsForm.addEventListener("submit", async function(event) {
        event.preventDefault();

        const technicalSkills = Array.from(
            document.querySelectorAll(
                'input[name="technicalSkills"]:checked'
            )
        ).map(skill => skill.value);

        const interests = Array.from(
            document.querySelectorAll(
                'input[name="interests"]:checked'
            )
        ).map(interest => interest.value);

        const programmingLevel =
            document.getElementById("programmingLevel").value;

        const webLevel =
            document.getElementById("webLevel").value;

        const databaseLevel =
            document.getElementById("databaseLevel").value;

        const careerGoal =
            document.getElementById("careerGoal").value;

        if (technicalSkills.length === 0) {
            alert("Please select at least one technical skill.");
            return;
        }

        if (interests.length === 0) {
            alert("Please select at least one area of interest.");
            return;
        }

        const skillProfile = {
            technicalSkills: technicalSkills,
            proficiency: {
                programming: programmingLevel,
                webDevelopment: webLevel,
                database: databaseLevel
            },
            interests: interests,
            careerGoal: careerGoal
        };

        try {
            const response = await fetch(
                window.CAREERPILOT_API_BASE + "/skills",
                {
                    method: "POST",
                    credentials: "include",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(skillProfile)
                }
            );

            const data = await response.json();

            if (!response.ok || !data.success) {
                alert(data.message || "Unable to save skill profile.");
                return;
            }

            displaySkillProfile(skillProfile);

            alert("Your Skill Assessment has been saved successfully!");

        } catch (error) {
            console.error("Save Skill Profile Error:", error);

            alert("Unable to connect to the server. Please try again.");
        }
    });
}

// =====================================
// LOAD DASHBOARD EXAMINATIONS
// =====================================

async function loadDashboardExaminations() {

    const examinationsContainer =
        document.getElementById("dashboardExaminationsList");

    // Run only on the Dashboard page
    if (!examinationsContainer) {
        return;
    }

    try {

        const response = await fetch(
            window.CAREERPILOT_API_BASE + "/examinations",
            {
                method: "GET",
                credentials: "include"
            }
        );

        if (!response.ok) {
            examinationsContainer.textContent =
                "Unable to load examinations.";
            return;
        }

        const result = await response.json();

        if (!result.success) {
            examinationsContainer.textContent =
                "Unable to retrieve examinations.";
            return;
        }

        const examinations = result.examinations;

        console.log("Examinations received:", examinations);
        console.log("Number of examinations:", examinations.length);

        // Show message if no examinations exist
        if (examinations.length === 0) {
            examinationsContainer.textContent =
                "No examinations scheduled.";
            return;
        }

        // Display examinations
        examinationsContainer.innerHTML = "";

        examinations.forEach(examination => {

            const taskItem = document.createElement("div");
            taskItem.className = "task-item";

            const details = document.createElement("div");

            const title = document.createElement("strong");
            title.textContent = examination.subject_name;

            const description = document.createElement("p");
            description.textContent = examination.examination_name;

            const examDate = document.createElement("p");

            if (examination.exam_date) {

                const dateValue =
                    String(examination.exam_date).slice(0, 10);

                const [year, month, day] = dateValue.split("-");

                const formattedDate = new Date(
                    Number(year),
                    Number(month) - 1,
                    Number(day)
                ).toLocaleDateString("en-IN", {
                    day: "numeric",
                    month: "long",
                    year: "numeric"
                });

                examDate.textContent = "Exam Date: " + formattedDate;

            } else {

                examDate.textContent = "Exam date not available";

            }


const status = document.createElement("span");

const dateValue =
    String(examination.exam_date).slice(0, 10);

const [year, month, day] = dateValue.split("-");

const examinationDate = new Date(
    Number(year),
    Number(month) - 1,
    Number(day)
);

const today = new Date();

const todayDate = new Date(
    today.getFullYear(),
    today.getMonth(),
    today.getDate()
);

if (examinationDate.getTime() < todayDate.getTime()) {

    status.className = "status completed";
    status.textContent = "Completed";

} else if (examinationDate.getTime() === todayDate.getTime()) {

    status.className = "status upcoming";
    status.textContent = "Today";

} else {

    status.className = "status upcoming";
    status.textContent = "Upcoming";

}


            details.appendChild(title);
            details.appendChild(description);
            details.appendChild(examDate);

            taskItem.appendChild(details);
            taskItem.appendChild(status);

            examinationsContainer.appendChild(taskItem);

        });

        console.log("Dashboard examinations loaded successfully.");

    } catch (error) {

        console.error("Dashboard Examinations Error:", error);

        examinationsContainer.textContent =
            "Unable to connect to the backend.";

    }

}

// Load dashboard examinations
loadDashboardExaminations();


// Function to display student skill profile

function displaySkillProfile(profile) {

    const resultSection =
        document.getElementById("skillsResult");

    const resultContent =
        document.getElementById("skillsResultContent");

    if (!resultSection || !resultContent) {
        return;
    }

    resultContent.innerHTML = `
        <h3>Technical Skills</h3>
        <p>${profile.technicalSkills.join(", ")}</p>

        <h3>Skill Proficiency</h3>
        <p>Programming: ${profile.proficiency.programming}</p>
        <p>Web Development: ${profile.proficiency.webDevelopment}</p>
        <p>Database: ${profile.proficiency.database}</p>

        <h3>Areas of Interest</h3>
        <p>${profile.interests.join(", ")}</p>

        <h3>Career Goal</h3>
        <p>${profile.careerGoal}</p>
    `;

    resultSection.hidden = false;
}


// Load previously saved skill profile


// Load previously saved skill profile from MySQL

async function loadSkillProfile() {

    try {

        const response = await fetch(
            window.CAREERPILOT_API_BASE + "/skills",
            {
                method: "GET",
                credentials: "include"
            }
        );

        if (!response.ok) {
            console.error("Unable to load skill profile.");
            return;
        }

        const result = await response.json();

        if (result.success && result.skillProfile) {

            displaySkillProfile(result.skillProfile);

            console.log("Skill profile loaded from MySQL.");

        } else {

            console.log("No saved skill profile found.");

        }

    } catch (error) {

        console.error("Load Skill Profile Error:", error);

    }
}

// Run when the page loads
loadSkillProfile();

/* =====================================
   CAREERPILOT AI MENTOR CHATBOT
===================================== */

// Get HTML elements
const mentorChatForm = document.getElementById("mentorChatForm");
const mentorInput = document.getElementById("mentorInput");
const chatMessages = document.getElementById("chatMessages");
const clearChatBtn = document.getElementById("clearChatBtn");
const mentorSendBtn = document.getElementById("mentorSendBtn");

// Store logged-in student's information
let mentorStudentContext = null;
let mentorContextLoading = false;
let mentorContextError = false;

// Load Student Context from Backend
async function loadMentorStudentContext() {

    try {

        mentorContextLoading = true;
        mentorContextError = false;

        const response = await fetch(
            window.CAREERPILOT_API_BASE + "/mentor/context",
            {
                method: "GET",
                credentials: "include"
            }
        );

        const data = await response.json();

        if (!response.ok || !data.success) {

            mentorContextError = true;

            console.error(
                "Unable to load Mentor student context:",
                data.message
            );

            return;
        }

        // Store all student information
        mentorStudentContext = data;

        console.log(
            "AI Mentor student context loaded successfully.",
            mentorStudentContext
        );

    } catch (error) {

        mentorContextError = true;

        console.error(
            "Load Mentor Student Context Error:",
            error
        );

    } finally {

        mentorContextLoading = false;
if (mentorSendBtn) {
    mentorSendBtn.disabled = mentorContextError;
  
}
    }
}
// Load context only on the Mentor page
const mentorContextPromise = mentorChatForm
    ? loadMentorStudentContext()
    : Promise.resolve();

// Function to display chat messages
function addChatMessage(sender, message) {

    const messageDiv = document.createElement("div");

    if (sender === "Student") {
        messageDiv.className = "student-message";
    } else {
        messageDiv.className = "mentor-message";
    }

    const heading = document.createElement("strong");
    heading.textContent = sender;

    const paragraph = document.createElement("p");
    paragraph.textContent = message;

    messageDiv.appendChild(heading);
    messageDiv.appendChild(paragraph);

    chatMessages.appendChild(messageDiv);

    // Automatically scroll to the latest message
    chatMessages.scrollTop = chatMessages.scrollHeight;
}


// Function to generate demo responses

// =====================================
// PERSONALIZED AI MENTOR RESPONSES
// =====================================

function getMentorResponse(question) {

    const userQuestion = question.toLowerCase();
    // Check whether student information is loading
    if (mentorContextLoading) {
        return "I'm loading your student information. Please wait a moment and try again.";
    }

    // Check whether student information failed to load
    if (mentorContextError || !mentorStudentContext) {
        return "I'm unable to load your student information. Please refresh the page or log in again.";
    }

    const context = mentorStudentContext;
    const student = context.student;
    const subjects = context.subjects || [];
    const assignments = context.pendingAssignments || [];
    const examinations = context.upcomingExaminations || [];
    const skills = context.skillProfile;

    // Format dates without timezone shifting
    function formatDate(dateValue) {

        if (!dateValue) {
            return "Date not specified";
        }

        const datePart = String(dateValue).slice(0, 10);
        const parts = datePart.split("-");

        if (parts.length !== 3) {
            return datePart;
        }

        return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }

    // Greeting
    if (/^(hello|hi|hey)\b/.test(userQuestion)) {

        return `Hello ${student.student_name}! Welcome back to CareerPilot AI. Your career goal is ${skills ? skills.career_goal : "not yet selected"}. How can I help you today?`;
    }

// Career goal
else if (
    (
        userQuestion.includes("career goal") ||
        userQuestion.includes("my goal")
    ) &&
    !userQuestion.includes("project")
) {

        return skills
            ? `Your current career goal is ${skills.career_goal}. Your selected interests are ${skills.interests.join(", ")}. I can help you build a learning plan towards this goal.`
            : "You haven't completed your Skill Assessment yet. Complete it to receive personalized career guidance.";
    }

    // Personalized Study Planning
    else if (
        userQuestion.includes("study plan") ||
        userQuestion.includes("study schedule") ||
        userQuestion.includes("what should i do")
    ) {

        let studyPlan = `Here is your personalized study plan based on your academic schedule:\n\n`;

        // Examination priorities
        if (examinations.length > 0) {

            studyPlan += `EXAMINATION PRIORITY:\n`;

            examinations.forEach((exam, index) => {

                studyPlan += `${index + 1}. Prepare for ${exam.examination_name} (${exam.subject_name}) - Date: ${formatDate(exam.exam_date)}.\n`;

            });

            studyPlan += `\nRevise important concepts and practise questions for your upcoming examinations.\n\n`;
        }

        // Assignment priorities
        if (assignments.length > 0) {

            studyPlan += `ASSIGNMENT PRIORITY:\n`;

            assignments.forEach((assignment, index) => {

                studyPlan += `${index + 1}. Complete ${assignment.assignment_title} (${assignment.subject_name}) - Due: ${formatDate(assignment.due_date)}.\n`;

            });

            studyPlan += `\nReserve time to complete and review your assignments before their deadlines.\n\n`;
        }

        // General recommendations
        studyPlan += `DAILY STUDY RECOMMENDATIONS:\n`;
        studyPlan += `1. Prioritize examination preparation.\n`;
        studyPlan += `2. Allocate time for assignment completion.\n`;
        studyPlan += `3. Revise your current semester subjects.\n`;
        studyPlan += `4. Practise programming regularly.\n`;
        studyPlan += `5. Continue developing skills towards your career goal: ${skills ? skills.career_goal : "complete your Skill Assessment"}.\n\n`;

        studyPlan += `Try to balance examination preparation, assignments and career skill development.`;

        return studyPlan;
    }

    // Pending assignments
    else if (
        userQuestion.includes("assignment") ||
        userQuestion.includes("pending work")
    ) {

        if (assignments.length === 0) {
            return "Great! You currently have no pending assignments recorded in CareerPilot AI.";
        }

        const assignmentDetails = assignments.map((item, index) => {

            return `${index + 1}. ${item.assignment_title} (${item.subject_name}) - Due: ${formatDate(item.due_date)}`;

        }).join("\n");

        return `You currently have ${assignments.length} pending assignment(s):\n\n${assignmentDetails}\n\nTry completing the assignments with the nearest due dates first.`;
    }

    // Upcoming examinations
    else if (
        userQuestion.includes("exam") ||
        userQuestion.includes("examination")
    ) {

        if (examinations.length === 0) {
            return "You currently have no upcoming examinations recorded in CareerPilot AI.";
        }

        const examDetails = examinations.map((exam, index) => {

            return `${index + 1}. ${exam.examination_name} - ${exam.subject_name} - Date: ${formatDate(exam.exam_date)}`;

        }).join("\n");

        return `Here are your upcoming examinations:\n\n${examDetails}\n\nStart revising the related subjects early and practise important questions.`;
    }

    // Current subjects and syllabus
else if (
    (
        userQuestion.includes("subject") ||
        userQuestion.includes("syllabus") ||
        userQuestion.includes("what should i study")
    ) &&
    !userQuestion.includes("data structure")
) {

        if (subjects.length === 0) {
            return "No subjects have been added for your current semester yet.";
        }

        const subjectDetails = subjects.map((subject, index) => {

            return `${index + 1}. ${subject.subject_name}: ${subject.syllabus || "Syllabus not added"}`;

        }).join("\n");

        return `Here are your current semester subjects and syllabus:\n\n${subjectDetails}\n\nYou can ask me to explain any of these topics.`;
    }

    // Existing technical skills
else if (
    userQuestion.includes("my skill") ||
    userQuestion.includes("technical skill") ||
    userQuestion.includes("current skills") ||
    userQuestion.includes("skills should i improve") ||
    userQuestion.includes("skill level") ||
    userQuestion.includes("proficiency level")
) {

        if (!skills) {
            return "Your Skill Assessment profile is not available yet. Please complete your assessment first.";
        }

        return `Your current technical skills are: ${skills.technical_skills.join(", ")}.\n\nYour proficiency levels are:\nProgramming: ${skills.programming_level}\nWeb Development: ${skills.web_level}\nDatabase: ${skills.database_level}\n\nSince your career goal is ${skills.career_goal}, you can gradually improve your programming and technical knowledge through regular practice and small projects.`;
    }

    // Career roadmap
    else if (
        userQuestion.includes("career roadmap") ||
        userQuestion.includes("roadmap")
    ) {

        const careerGoal = skills
            ? skills.career_goal
            : "Software Developer";

        return `Your selected career goal is ${careerGoal}.\n\nA suggested learning path is:\n1. Strengthen programming fundamentals.\n2. Practise Data Structures and Algorithms.\n3. Improve your database and problem-solving skills.\n4. Learn technologies related to ${careerGoal}.\n5. Build practical projects.\n6. Develop a portfolio of your work.\n\nWe can gradually adapt this roadmap as your skills improve.`;
    }

    // Data Structures
    else if (
        userQuestion.includes("data structure") ||
        userQuestion.includes("array") ||
        userQuestion.includes("linked list")
    ) {

        const subject = subjects.find(item =>
            item.subject_name.toLowerCase().includes("data structure")
        );

        if (subject) {
            return `Data Structures is one of your current subjects.\n\nYour recorded syllabus includes: ${subject.syllabus}.\n\nStart with Arrays, understand how Linked Lists work, and then study Stacks. Practise simple examples for each topic.`;
        }

        return "Data Structures helps organize and manage information efficiently. Start with Arrays, Linked Lists, Stacks, Queues, Trees and Graphs.";
    }

    // Python
    else if (userQuestion.includes("python")) {

        return `To strengthen your programming skills, start learning Python fundamentals such as variables, data types, conditions, loops, functions, lists and dictionaries.\n\nSince your career goal is ${skills ? skills.career_goal : "Software Developer"}, Python can also help you explore automation and Artificial Intelligence.`;
    }

    // Artificial Intelligence and AI Engineer Skills
    else if (
        userQuestion.includes("ai engineer") ||
        userQuestion.includes("skills required") ||
        userQuestion.includes("artificial intelligence") ||
        userQuestion.includes("machine learning") ||
        userQuestion.includes("ai")
    ) {

        return `Your selected career goal is ${skills ? skills.career_goal : "AI Engineer"}.

To become an AI Engineer, gradually develop these skills:

1. Programming:
   Learn Python, functions, OOP and problem-solving.

2. Mathematics:
   Understand Linear Algebra, Calculus, Probability and Statistics.

3. Data Handling:
   Learn NumPy, Pandas and data visualization.

4. Machine Learning:
   Study supervised learning, unsupervised learning and model evaluation.

5. Deep Learning:
   Explore neural networks and frameworks such as TensorFlow or PyTorch.

6. Databases:
   Practise SQL and understand how to manage datasets.

7. Practical Projects:
   Build projects such as prediction systems, image classification and recommendation systems.

Your current technical skills are ${skills ? skills.technical_skills.join(", ") : "not yet recorded"}.

Your programming proficiency is ${skills ? skills.programming_level : "not available"}.

Recommended next step: Strengthen your Python programming fundamentals before moving into Machine Learning.`;
    }

    // Web Development
    else if (
        userQuestion.includes("web development") ||
        userQuestion.includes("html") ||
        userQuestion.includes("css") ||
        userQuestion.includes("javascript")
    ) {

        return `Your recorded technical skills include ${skills ? skills.technical_skills.join(", ") : "no skills recorded yet"}.\n\nContinue practising HTML, CSS and JavaScript. Then explore responsive design, APIs and backend development through small projects.`;
    }

   

       

    // Database and SQL
    else if (
        userQuestion.includes("database") ||
        userQuestion.includes("sql")
    ) {

        return `Your recorded database proficiency is ${skills ? skills.database_level : "not available"}.\n\nStart with tables, records, primary keys and foreign keys. Then practise SELECT, INSERT, UPDATE, DELETE, JOIN and GROUP BY commands.`;
    }

    // Project guidance
    else if (userQuestion.includes("project")) {

        return `Since your career goal is ${skills ? skills.career_goal : "Software Developer"}, consider building projects that match your interests.\n\nYou can begin with a Student Management System, a Personal Portfolio Website or a small application related to Artificial Intelligence. Build each project step by step.`;
    }

    // Default response
    else {

        return `Hello ${student.student_name}! I can help you with your current subjects, syllabus, pending assignments, upcoming examinations, technical skills and your ${skills ? skills.career_goal : "career"} goal.\n\nTry asking me about your assignments, exams, subjects or skills.`;
    }
}


// Handle student message submission
if (mentorChatForm) {

    mentorChatForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const question = mentorInput.value.trim();

        if (question === "") {
            return;
        }

        // Display student message
        addChatMessage("Student", question);

        // Generate mentor response
        const response = getMentorResponse(question);

        // Display mentor response
        addChatMessage("CareerPilot AI", response);

        // Clear input box
        mentorInput.value = "";

        mentorInput.focus();

    });

}


// Handle suggested questions
const suggestionButtons = document.querySelectorAll(".suggestion-btn");

suggestionButtons.forEach(function(button) {

    button.addEventListener("click", function() {

        const question = button.textContent.trim();

        addChatMessage("Student", question);

        const response = getMentorResponse(question);

        addChatMessage("CareerPilot AI", response);

    });

});


// Handle Clear Chat button
if (clearChatBtn) {

    clearChatBtn.addEventListener("click", function() {

        const confirmClear = confirm(
            "Are you sure you want to clear the conversation?"
        );

        if (confirmClear) {

            chatMessages.innerHTML = "";

            addChatMessage(
                "CareerPilot AI",
                "Hello! Welcome to CareerPilot AI. How can I help you today?"
            );

        }

    });

}

/* =====================================
   CAREER ROADMAP - LOAD SKILL PROFILE
===================================== */

const roadmapCareerGoalDisplay =
    document.getElementById("careerGoalDisplay");

const roadmapCurrentSkillsDisplay =
    document.getElementById("currentSkillsDisplay");


async function loadRoadmapProfile() {

    try {

        const response = await fetch(
            window.CAREERPILOT_API_BASE + "/skills",
            {
                method: "GET",
                credentials: "include"
            }
        );

        if (!response.ok) {
            console.error("Unable to load roadmap skill profile.");
            return;
        }

        const result = await response.json();

        if (!result.success || !result.skillProfile) {

            if (roadmapCareerGoalDisplay) {
                roadmapCareerGoalDisplay.textContent =
                    "No career goal found. Please complete your Skill Assessment first.";
            }

            if (roadmapCurrentSkillsDisplay) {
                roadmapCurrentSkillsDisplay.textContent =
                    "No technical skills found. Please complete your Skill Assessment first.";
            }

            return;
        }

        const profile = result.skillProfile;

        if (roadmapCareerGoalDisplay) {
            roadmapCareerGoalDisplay.textContent =
                profile.careerGoal || "Not selected";
        }

        if (roadmapCurrentSkillsDisplay) {

            roadmapCurrentSkillsDisplay.innerHTML = "";

            const skillsHeading = document.createElement("h3");
            skillsHeading.textContent = "Technical Skills";

            const skillsList = document.createElement("ul");

            (profile.technicalSkills || []).forEach(function(skill) {
                const listItem = document.createElement("li");
                listItem.textContent = skill;
                skillsList.appendChild(listItem);
            });

            const interestsHeading = document.createElement("h3");
            interestsHeading.textContent = "Areas of Interest";

            const interestsList = document.createElement("ul");

            (profile.interests || []).forEach(function(interest) {
                const listItem = document.createElement("li");
                listItem.textContent = interest;
                interestsList.appendChild(listItem);
            });

            const proficiencyHeading = document.createElement("h3");
            proficiencyHeading.textContent = "Proficiency Levels";

            const proficiencyList = document.createElement("ul");

            Object.entries(profile.proficiency || {}).forEach(function(item) {
                const listItem = document.createElement("li");

                listItem.textContent =
                    item[0] + ": " + item[1];

                proficiencyList.appendChild(listItem);
            });

            roadmapCurrentSkillsDisplay.appendChild(skillsHeading);
            roadmapCurrentSkillsDisplay.appendChild(skillsList);

            roadmapCurrentSkillsDisplay.appendChild(interestsHeading);
            roadmapCurrentSkillsDisplay.appendChild(interestsList);

            roadmapCurrentSkillsDisplay.appendChild(proficiencyHeading);
            roadmapCurrentSkillsDisplay.appendChild(proficiencyList);
        }

        console.log("Roadmap skill profile loaded from MySQL.");

    } catch (error) {

        console.error("Roadmap Profile Error:", error);

    }
}

// Run only when the Roadmap page is opened
if (roadmapCareerGoalDisplay) {
    loadRoadmapProfile();
}

/* =====================================
   GENERATE PERSONALIZED CAREER ROADMAP
===================================== */

const generateRoadmapBtn =
    document.getElementById("generateRoadmapBtn");

const roadmapStagesContainer =
    document.getElementById("roadmapStages");

async function generatePersonalizedRoadmap() {

    let result;

    // Retrieve the saved skill profile from MySQL
    try {

        const response = await fetch(
            window.CAREERPILOT_API_BASE + "/skills",
            {
                method: "GET",
                credentials: "include"
            }
        );

        if (!response.ok) {
            alert("Unable to retrieve your Skill Assessment.");
            return;
        }

        result = await response.json();

    } catch (error) {

        console.error("Roadmap Generation Error:", error);

        alert("Unable to connect to the server. Please try again.");

        return;
    }

    // Check whether a skill profile exists
    if (!result.success || !result.skillProfile) {

        alert("Please complete your Skill Assessment first.");

        return;
    }

    const profile = result.skillProfile;

    const careerGoal = profile.careerGoal;

    // Keep the existing roadmap generation code below this line.
    let roadmap = [];

    if (careerGoal === "AI Engineer") {

        roadmap = [
            {
                title: "Stage 1: Programming Foundations",
                duration: "Month 1-2",
                topics: "Python, Mathematics, Statistics and Problem Solving",
                project: "Build a Python Calculator and Data Analysis Tool"
            },
            {
                title: "Stage 2: Machine Learning",
                duration: "Month 3-4",
                topics: "NumPy, Pandas, Machine Learning and Data Visualization",
                project: "Build a Student Performance Prediction Demo"
            },
            {
                title: "Stage 3: Artificial Intelligence",
                duration: "Month 5-6",
                topics: "Neural Networks, Deep Learning and AI Fundamentals",
                project: "Build a Simple AI-Based Recommendation Demo"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "Portfolio, GitHub, Problem Solving and Interview Preparation",
                project: "Publish Your AI Projects in a Portfolio"
            }
        ];

    } else if (careerGoal === "Software Developer") {

        roadmap = [
            {
                title: "Stage 1: Programming Foundations",
                duration: "Month 1-2",
                topics: "C, C++, Java or Python and Data Structures",
                project: "Build a Student Management System"
            },
            {
                title: "Stage 2: Web and Database Development",
                duration: "Month 3-4",
                topics: "HTML, CSS, JavaScript, SQL and Database Design",
                project: "Build a Student Registration Website"
            },
            {
                title: "Stage 3: Application Development",
                duration: "Month 5-6",
                topics: "Backend Development, APIs and Software Testing",
                project: "Build a Full-Stack Web Application"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "Git, GitHub, Coding Practice and Interview Preparation",
                project: "Create a Professional Project Portfolio"
            }
        ];

    } else if (careerGoal === "Data Scientist") {

        roadmap = [
            {
                title: "Stage 1: Foundations",
                duration: "Month 1-2",
                topics: "Python, Mathematics, Statistics and SQL",
                project: "Analyze a Student Performance Dataset"
            },
            {
                title: "Stage 2: Data Analysis",
                duration: "Month 3-4",
                topics: "NumPy, Pandas and Data Visualization",
                project: "Build a Data Analysis Dashboard"
            },
            {
                title: "Stage 3: Machine Learning",
                duration: "Month 5-6",
                topics: "Machine Learning Algorithms and Model Evaluation",
                project: "Build a Simple Prediction Model"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "Portfolio, Case Studies and Interview Preparation",
                project: "Publish Your Data Science Projects"
            }
        ];

    } else if (careerGoal === "Cloud Engineer") {

        roadmap = [
            {
                title: "Stage 1: IT Foundations",
                duration: "Month 1-2",
                topics: "Networking, Linux, Operating Systems and Programming",
                project: "Create a Linux Administration Practice Project"
            },
            {
                title: "Stage 2: Cloud Fundamentals",
                duration: "Month 3-4",
                topics: "Cloud Computing, Virtual Machines and Storage",
                project: "Design a Basic Cloud Architecture"
            },
            {
                title: "Stage 3: Cloud Services",
                duration: "Month 5-6",
                topics: "Cloud Deployment, Security and Automation",
                project: "Deploy a Simple Web Application"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "Cloud Projects, Portfolio and Interview Preparation",
                project: "Document Your Cloud Projects"
            }
        ];

    } else if (careerGoal === "Cybersecurity Analyst") {

        roadmap = [
            {
                title: "Stage 1: Computer Foundations",
                duration: "Month 1-2",
                topics: "Networking, Linux and Operating System Fundamentals",
                project: "Create a Network Concepts Learning Project"
            },
            {
                title: "Stage 2: Security Fundamentals",
                duration: "Month 3-4",
                topics: "Security Principles, Cryptography and Access Control",
                project: "Create a Security Awareness Guide"
            },
            {
                title: "Stage 3: Defensive Security",
                duration: "Month 5-6",
                topics: "Log Analysis, Monitoring and Incident Response Concepts",
                project: "Analyze Sample Security Logs"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "Security Documentation, Portfolio and Interview Preparation",
                project: "Create a Defensive Security Portfolio"
            }
        ];

    } else if (careerGoal === "Web Developer") {

        roadmap = [
            {
                title: "Stage 1: Web Foundations",
                duration: "Month 1-2",
                topics: "HTML, CSS and Responsive Web Design",
                project: "Build a Personal Portfolio Website"
            },
            {
                title: "Stage 2: JavaScript Development",
                duration: "Month 3-4",
                topics: "JavaScript, DOM Manipulation and APIs",
                project: "Build an Interactive To-Do Application"
            },
            {
                title: "Stage 3: Full-Stack Development",
                duration: "Month 5-6",
                topics: "Backend Development, Node.js and SQL",
                project: "Build a Full-Stack Student Application"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "GitHub, Portfolio and Interview Preparation",
                project: "Publish Your Web Development Portfolio"
            }
        ];

    } else {

        alert("No roadmap is available for this career goal yet.");
        return;
    }

    roadmapStagesContainer.innerHTML = "";

    const heading = document.createElement("h3");
    heading.textContent = "Personalized Roadmap: " + careerGoal;

    roadmapStagesContainer.appendChild(heading);

    roadmap.forEach(function(stage) {

        const stageDiv = document.createElement("div");
        stageDiv.className = "roadmap-stage";

        const title = document.createElement("h3");
        title.textContent = stage.title;

        const duration = document.createElement("p");
        duration.textContent = "Suggested Timeline: " + stage.duration;

        const topics = document.createElement("p");
        topics.textContent = "Learning Topics: " + stage.topics;

        const project = document.createElement("p");
        project.textContent = "Recommended Project: " + stage.project;

        stageDiv.appendChild(title);
        stageDiv.appendChild(duration);
        stageDiv.appendChild(topics);
        stageDiv.appendChild(project);

        roadmapStagesContainer.appendChild(stageDiv);

    });

    localStorage.setItem(
        "generatedCareerRoadmap",
        JSON.stringify(roadmap)
    );
}

if (generateRoadmapBtn) {
    generateRoadmapBtn.addEventListener(
        "click",
        generatePersonalizedRoadmap
    );
}

/* =====================================
   LOAD PREVIOUSLY GENERATED ROADMAP
===================================== */

function loadSavedCareerRoadmap() {

    const savedRoadmap =
        localStorage.getItem("generatedCareerRoadmap");

    if (!savedRoadmap || !roadmapStagesContainer) {
        return;
    }

    const roadmap = JSON.parse(savedRoadmap);

    roadmapStagesContainer.innerHTML = "";

    const heading = document.createElement("h3");

    heading.textContent = "Your Previously Generated Career Roadmap";

    roadmapStagesContainer.appendChild(heading);

    roadmap.forEach(function(stage) {

        const stageDiv = document.createElement("div");
        stageDiv.className = "roadmap-stage";

        const title = document.createElement("h3");
        title.textContent = stage.title;

        const duration = document.createElement("p");
        duration.textContent =
            "Suggested Timeline: " + stage.duration;

        const topics = document.createElement("p");
        topics.textContent =
            "Learning Topics: " + stage.topics;

        const project = document.createElement("p");
        project.textContent =
            "Recommended Project: " + stage.project;

        stageDiv.appendChild(title);
        stageDiv.appendChild(duration);
        stageDiv.appendChild(topics);
        stageDiv.appendChild(project);

        roadmapStagesContainer.appendChild(stageDiv);

    });
}

// Load saved roadmap when Roadmap page opens
if (roadmapStagesContainer) {
    loadSavedCareerRoadmap();
}

// =====================================
// CONNECT FRONTEND WITH BACKEND API
// =====================================

async function checkBackendConnection() {

    try {

        const response = await fetch(
            window.CAREERPILOT_API_BASE + "/status"
        );

        const data = await response.json();

        if (data.success) {

            console.log(
                "Backend Connected:",
                data.message
            );

        }

    } catch (error) {

        console.error(
            "Backend Connection Failed:",
            error
        );

    }

}

// Check backend only when Dashboard is opened
if (document.getElementById("careerGoalDisplay") === null &&
    document.querySelector(".mentor-container") === null &&
    window.location.pathname.endsWith("/dashboard.html")) {

    checkBackendConnection();

}
// =====================================
// DISPLAY LOGGED-IN STUDENT DETAILS
// =====================================

(async function displayLoggedInStudent() {
    if (!document.getElementById("dashboardStudentName")) {
        return;
    }

    try {
        const response = await fetch(
            window.CAREERPILOT_API_BASE + "/me",
            {
                method: "GET",
                credentials: "include"
            }
        );

        if (!response.ok) {
            window.location.href = "login.html";
            return;
        }

        const result = await response.json();

        if (!result.success || !result.student) {
            window.location.href = "login.html";
            return;
        }

        const student = result.student;

        document.getElementById("dashboardStudentName").textContent =
            student.studentName;

        document.getElementById("dashboardDepartment").textContent =
            student.department + " Student";

        document.getElementById("dashboardWelcome").textContent =
            "Welcome back, " + student.studentName + "! 👋";

        const yearNames = {
            1: "1st Year",
            2: "2nd Year",
            3: "3rd Year",
            4: "4th Year"
        };

        document.getElementById("dashboardYear").textContent =
            yearNames[student.year] || student.year + " Year";

        document.getElementById("dashboardSemester").textContent =
            "Semester " + student.semester;

    } catch (error) {
        console.error("Dashboard Authentication Error:", error);
        alert("Unable to connect to the backend. Please try again.");
    }
})();

// =====================================
// STUDENT LOGOUT
// =====================================

const logoutBtn = document.getElementById("logoutBtn");

if (logoutBtn) {
    logoutBtn.addEventListener("click", async function(event) {
        event.preventDefault();

        try {
            const response = await fetch(
                window.CAREERPILOT_API_BASE + "/logout",
                {
                    method: "POST",
                    credentials: "include"
                }
            );

            const result = await response.json();

            if (response.ok && result.success) {
                alert("You have successfully logged out.");
                window.location.href = "login.html";
            } else {
                alert(result.message || "Logout failed. Please try again.");
            }

        } catch (error) {
            console.error("Logout Error:", error);
            alert("Unable to connect to the backend. Please try again.");
        }
    });
}
