
// Student Registration

// =====================================
// STUDENT REGISTRATION - BACKEND CONNECTION
// =====================================
// STUDENT REGISTRATION
// =====================================

const registrationForm =
    document.getElementById("registrationForm");

if (registrationForm) {

    registrationForm.addEventListener("submit", async function(event) {

        event.preventDefault();

        const studentName =
            document.getElementById("studentName").value.trim();

        const email =
            document.getElementById("email").value.trim();

        const college =
            document.getElementById("college").value.trim();

        const department =
            document.getElementById("department").value;

        const year =
            document.getElementById("year").value;

        const semester =
            document.getElementById("semester").value;

        const password =
            document.getElementById("password").value;

        const confirmPassword =
            document.getElementById("confirmPassword").value;

        // Validate passwords
        if (password !== confirmPassword) {
            alert("Passwords do not match!");
            return;
        }

        // Prepare student data
        const studentData = {
            studentName: studentName,
            email: email,
            college: college,
            department: department,
            year: year,
            semester: semester,
            password: password,
            confirmPassword: confirmPassword
        };

        try {

            const response = await fetch(
                "http://localhost:3000/api/student",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(studentData)
                }
            );

            const result = await response.json();

            if (response.ok && result.success) {

                alert(result.message);

                registrationForm.reset();

            } else {

                alert(result.message || "Registration failed.");

            }

        } catch (error) {

            console.error("Registration Error:", error);

            alert("Unable to connect to the backend.");

        }

    });

}
if (registrationForm) {

    registrationForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const password =
            document.getElementById("password").value;

        const confirmPassword =
            document.getElementById("confirmPassword").value;

        if (password !== confirmPassword) {

            alert("Passwords do not match!");
            return;

        }

        alert("Registration form completed successfully!");

    });

}


// =====================================
// STUDENT LOGIN
// =====================================

const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", async function(event) {

        event.preventDefault();

        const email =
            document.getElementById("loginEmail").value.trim();

        const password =
            document.getElementById("loginPassword").value;

        try {

const response = await fetch(
    "http://localhost:3000/api/login",
    {
        method: "POST",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: email,
            password: password
        })
    }
);

            const result = await response.json();

            if (response.ok && result.success) {

                // Store student profile for this browser tab


                alert("Login successful! Welcome to CareerPilot AI.");

                window.location.href = "dashboard.html";

            } else {

                alert(result.message || "Invalid email or password.");

            }

        } catch (error) {

            console.error("Login Error:", error);

            alert("Unable to connect to the backend.");

        }

    });

}

// Dashboard AI Mentor Button

function showDashboardMessage() {

    alert(
        "Welcome to CareerPilot AI Mentor! " +
        "AI guidance functionality will be integrated in a later step."
    );

}

// ======================================
// ACADEMIC MANAGEMENT MODULE
// ======================================

// Load saved academic information

function getAcademicData(key) {

    return JSON.parse(localStorage.getItem(key) || "[]");

}


// Save academic information

function saveAcademicData(key, data) {

    localStorage.setItem(key, JSON.stringify(data));

}


// Generate unique record ID

function createRecordId() {

    return Date.now().toString() +
        Math.random().toString(16).slice(2);

}


// Safely display user-entered text in HTML

function escapeAcademicText(value) {

    return String(value ?? "").replace(/[&<>"']/g, function(char) {

        const entities = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };

        return entities[char];

    });

}


// Display records in a table

function displayAcademicRecords(key, elementId, columns) {

    const records = getAcademicData(key);

    const tableBody = document.getElementById(elementId);

    if (!tableBody) return;

    if (records.length === 0) {

        tableBody.innerHTML =
            `<tr><td colspan="${columns.length}"
            class="empty-message">No records added yet.</td></tr>`;

        return;

    }

    tableBody.innerHTML = records.map(function(record) {

        const cells = columns.map(function(column) {

            if (column === "syllabus") {

                return `<td>${escapeAcademicText(record.syllabus || "Not entered")}</td>`;

            }

            if (column === "status") {

                const status = record.status || "Pending";

                return `<td>
                    <button type="button"
                    onclick="toggleAssignmentStatus('${record.id}')">
                    ${escapeAcademicText(status)}
                    </button>
                </td>`;

            }

            return `<td>${escapeAcademicText(record[column])}</td>`;

        }).join("");

        return `<tr>
            ${cells}
            <td>
                <button type="button"
                onclick="deleteAcademicRecord('${key}','${record.id}')">
                Delete
                </button>
            </td>
        </tr>`;

    }).join("");

}


// ======================================
// SUBJECT MANAGEMENT
// ======================================

const subjectForm = document.getElementById("subjectForm");

if (subjectForm) {

    subjectForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const subjects = getAcademicData("subjects");

        subjects.push({

            id: createRecordId(),

            semester:
                document.getElementById("subjectSemester").value,

            name:
                document.getElementById("subjectName").value.trim(),

            code:
                document.getElementById("subjectCode").value.trim(),

            credits:
                document.getElementById("subjectCredits").value,

            syllabus:
                document.getElementById("subjectSyllabus").value.trim()

        });

        saveAcademicData("subjects", subjects);

        subjectForm.reset();

        renderAcademicPage();

        alert("Subject added successfully!");

    });

}


// ======================================
// TIMETABLE MANAGEMENT
// ======================================

const timetableForm = document.getElementById("timetableForm");

if (timetableForm) {

    timetableForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const start = document.getElementById("classStart").value;

        const end = document.getElementById("classEnd").value;

        if (start >= end) {

            alert("End time must be later than start time.");

            return;

        }

        const timetable = getAcademicData("timetable");

        timetable.push({

            id: createRecordId(),

            day: document.getElementById("classDay").value,

            subject: document.getElementById("classSubject").value.trim(),

            start: start,

            end: end,

            room: document.getElementById("classroom").value.trim()

        });

        saveAcademicData("timetable", timetable);

        timetableForm.reset();

        renderAcademicPage();

        alert("Class added successfully!");

    });

}


// ======================================
// ASSIGNMENT MANAGEMENT
// ======================================

const assignmentForm = document.getElementById("assignmentForm");

if (assignmentForm) {

    assignmentForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const assignments = getAcademicData("assignments");

        assignments.push({

            id: createRecordId(),

            title:
                document.getElementById("assignmentTitle").value.trim(),

            subject:
                document.getElementById("assignmentSubject").value.trim(),

            date:
                document.getElementById("assignmentDate").value,

            status: "Pending"

        });

        saveAcademicData("assignments", assignments);

        assignmentForm.reset();

        renderAcademicPage();

        alert("Assignment added successfully!");

    });

}


// ======================================
// EXAMINATION MANAGEMENT
// ======================================

const examForm = document.getElementById("examForm");

if (examForm) {

    examForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const exams = getAcademicData("examinations");

        exams.push({

            id: createRecordId(),

            name: document.getElementById("examName").value.trim(),

            subject: document.getElementById("examSubject").value.trim(),

            date: document.getElementById("examDate").value

        });

        saveAcademicData("examinations", exams);

        examForm.reset();

        renderAcademicPage();

        alert("Examination added successfully!");

    });

}


// ======================================
// DELETE ACADEMIC RECORD
// ======================================

function deleteAcademicRecord(key, id) {

    if (!confirm("Are you sure you want to delete this record?")) {

        return;

    }

    const records = getAcademicData(key);

    const updatedRecords = records.filter(function(record) {

        return record.id !== id;

    });

    saveAcademicData(key, updatedRecords);

    renderAcademicPage();

}


// ======================================
// CHANGE ASSIGNMENT STATUS
// ======================================

function toggleAssignmentStatus(id) {

    const assignments = getAcademicData("assignments");

    const updatedAssignments = assignments.map(function(item) {

        if (item.id === id) {

            item.status =
                item.status === "Pending" ? "Completed" : "Pending";

        }

        return item;

    });

    saveAcademicData("assignments", updatedAssignments);

    renderAcademicPage();

}


// ======================================
// DISPLAY ALL ACADEMIC INFORMATION
// ======================================

function renderAcademicPage() {

    displayAcademicRecords(
        "subjects",
        "subjectList",
        ["semester", "name", "code", "credits", "syllabus"]
    );

    displayAcademicRecords(
        "timetable",
        "timetableList",
        ["day", "subject", "start", "end", "room"]
    );

    displayAcademicRecords(
        "assignments",
        "assignmentList",
        ["title", "subject", "date", "status"]
    );

    displayAcademicRecords(
        "examinations",
        "examList",
        ["name", "subject", "date"]
    );

}


// Load saved records when the page opens

renderAcademicPage();

/* =====================================
   STUDENT SKILL ASSESSMENT FUNCTIONALITY
===================================== */

const skillsForm = document.getElementById("skillsForm");

if (skillsForm) {

    skillsForm.addEventListener("submit", function(event) {

        event.preventDefault();

        // Collect selected technical skills
        const technicalSkills = Array.from(
            document.querySelectorAll(
                'input[name="technicalSkills"]:checked'
            )
        ).map(skill => skill.value);

        // Collect selected interests
        const interests = Array.from(
            document.querySelectorAll(
                'input[name="interests"]:checked'
            )
        ).map(interest => interest.value);

        // Collect proficiency levels
        const programmingLevel =
            document.getElementById("programmingLevel").value;

        const webLevel =
            document.getElementById("webLevel").value;

        const databaseLevel =
            document.getElementById("databaseLevel").value;

        // Collect career goal
        const careerGoal =
            document.getElementById("careerGoal").value;

        // Validate selections
        if (technicalSkills.length === 0) {
            alert("Please select at least one technical skill.");
            return;
        }

        if (interests.length === 0) {
            alert("Please select at least one area of interest.");
            return;
        }

        // Create student skill profile
        const skillProfile = {
            technicalSkills: technicalSkills,

            proficiency: {
                programming: programmingLevel,
                webDevelopment: webLevel,
                database: databaseLevel
            },

            interests: interests,

            careerGoal: careerGoal
        };

        // Save profile in browser storage
        localStorage.setItem(
            "studentSkillProfile",
            JSON.stringify(skillProfile)
        );

        // Display the saved profile
        displaySkillProfile(skillProfile);

        alert("Your Skill Assessment has been saved successfully!");

    });

}


// Function to display student skill profile

function displaySkillProfile(profile) {

    const resultSection =
        document.getElementById("skillsResult");

    const resultContent =
        document.getElementById("skillsResultContent");

    if (!resultSection || !resultContent) {
        return;
    }

    resultContent.innerHTML = `
        <h3>Technical Skills</h3>
        <p>${profile.technicalSkills.join(", ")}</p>

        <h3>Skill Proficiency</h3>
        <p>Programming: ${profile.proficiency.programming}</p>
        <p>Web Development: ${profile.proficiency.webDevelopment}</p>
        <p>Database: ${profile.proficiency.database}</p>

        <h3>Areas of Interest</h3>
        <p>${profile.interests.join(", ")}</p>

        <h3>Career Goal</h3>
        <p>${profile.careerGoal}</p>
    `;

    resultSection.hidden = false;
}


// Load previously saved skill profile

function loadSkillProfile() {

    const savedProfile =
        localStorage.getItem("studentSkillProfile");

    if (savedProfile) {

        const profile = JSON.parse(savedProfile);

        displaySkillProfile(profile);

    }

}


// Run when the page loads

loadSkillProfile();

/* =====================================
   CAREERPILOT AI MENTOR CHATBOT
===================================== */

// Get HTML elements
const mentorChatForm = document.getElementById("mentorChatForm");
const mentorInput = document.getElementById("mentorInput");
const chatMessages = document.getElementById("chatMessages");
const clearChatBtn = document.getElementById("clearChatBtn");

// Function to display chat messages
function addChatMessage(sender, message) {

    const messageDiv = document.createElement("div");

    if (sender === "Student") {
        messageDiv.className = "student-message";
    } else {
        messageDiv.className = "mentor-message";
    }

    const heading = document.createElement("strong");
    heading.textContent = sender;

    const paragraph = document.createElement("p");
    paragraph.textContent = message;

    messageDiv.appendChild(heading);
    messageDiv.appendChild(paragraph);

    chatMessages.appendChild(messageDiv);

    // Automatically scroll to the latest message
    chatMessages.scrollTop = chatMessages.scrollHeight;
}


// Function to generate demo responses
function getMentorResponse(question) {

    const userQuestion = question.toLowerCase();

    if (
        userQuestion.includes("hello") ||
        userQuestion.includes("hi")
    ) {
        return "Hello! Welcome to CareerPilot AI. How can I help you with your studies or career today?";
    }

    else if (
        userQuestion.includes("data structure") ||
        userQuestion.includes("array") ||
        userQuestion.includes("linked list")
    ) {
        return "Data Structures are ways of organizing and storing data efficiently. Important topics include Arrays, Linked Lists, Stacks, Queues, Trees and Graphs. Start by understanding Arrays and Linked Lists, then practise simple programming problems.";
    }

    else if (
        userQuestion.includes("python")
    ) {
        return "To learn Python, start with variables, data types, operators, conditional statements, loops, functions, lists and dictionaries. After learning the basics, build small projects such as a calculator or student management system.";
    }

    else if (
        userQuestion.includes("career roadmap") ||
        userQuestion.includes("roadmap")
    ) {
        return "A good CSE career roadmap includes: 1. Learn programming fundamentals. 2. Study Data Structures and Algorithms. 3. Learn database concepts. 4. Explore a specialization such as AI, Web Development or Cloud Computing. 5. Build projects. 6. Practise problem-solving and prepare for interviews.";
    }

    else if (
        userQuestion.includes("artificial intelligence") ||
        userQuestion.includes("machine learning") ||
        userQuestion.includes("ai")
    ) {
        return "To explore Artificial Intelligence, first learn Python and basic mathematics. Then study data handling, statistics, machine learning fundamentals and model evaluation. Build small projects as you progress.";
    }

    else if (
        userQuestion.includes("web development") ||
        userQuestion.includes("html") ||
        userQuestion.includes("css") ||
        userQuestion.includes("javascript")
    ) {
        return "Web Development involves creating websites and web applications. Learn HTML for structure, CSS for styling and JavaScript for interactivity. Then explore responsive design, APIs and backend development.";
    }

    else if (
        userQuestion.includes("exam") ||
        userQuestion.includes("study")
    ) {
        return "Create a study timetable, divide your syllabus into smaller topics, revise regularly and practise questions. Give priority to topics you find difficult and leave time for revision.";
    }

    else if (
        userQuestion.includes("project")
    ) {
        return "Start with a small project that solves a real problem. Examples include a Student Management System, Personal Portfolio Website, Library Management System or Expense Tracker. Build it step by step and document your work.";
    }

    else if (
        userQuestion.includes("database") ||
        userQuestion.includes("sql")
    ) {
        return "Start learning database fundamentals such as tables, records, fields, primary keys and foreign keys. Then practise SQL commands including SELECT, INSERT, UPDATE, DELETE, JOIN and GROUP BY.";
    }

    else {
        return "That is an interesting question! I am currently using demo responses. Try asking me about Python, Data Structures, Web Development, AI, SQL, projects or career roadmaps. Real AI integration will be added in a later development step.";
    }
}


// Handle student message submission
if (mentorChatForm) {

    mentorChatForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const question = mentorInput.value.trim();

        if (question === "") {
            return;
        }

        // Display student message
        addChatMessage("Student", question);

        // Generate mentor response
        const response = getMentorResponse(question);

        // Display mentor response
        addChatMessage("CareerPilot AI", response);

        // Clear input box
        mentorInput.value = "";

        mentorInput.focus();

    });

}


// Handle suggested questions
const suggestionButtons = document.querySelectorAll(".suggestion-btn");

suggestionButtons.forEach(function(button) {

    button.addEventListener("click", function() {

        const question = button.textContent.trim();

        addChatMessage("Student", question);

        const response = getMentorResponse(question);

        addChatMessage("CareerPilot AI", response);

    });

});


// Handle Clear Chat button
if (clearChatBtn) {

    clearChatBtn.addEventListener("click", function() {

        const confirmClear = confirm(
            "Are you sure you want to clear the conversation?"
        );

        if (confirmClear) {

            chatMessages.innerHTML = "";

            addChatMessage(
                "CareerPilot AI",
                "Hello! Welcome to CareerPilot AI. How can I help you today?"
            );

        }

    });

}

/* =====================================
   CAREER ROADMAP - LOAD SKILL PROFILE
===================================== */

const roadmapCareerGoalDisplay =
    document.getElementById("careerGoalDisplay");

const roadmapCurrentSkillsDisplay =
    document.getElementById("currentSkillsDisplay");

function loadRoadmapProfile() {

    const savedProfile = localStorage.getItem("studentSkillProfile");

    if (!savedProfile) {

        if (roadmapCareerGoalDisplay) {
            roadmapCareerGoalDisplay.textContent =
                "No career goal found. Please complete your Skill Assessment first.";
        }

        if (roadmapCurrentSkillsDisplay) {
            roadmapCurrentSkillsDisplay.textContent =
                "No technical skills found. Please complete your Skill Assessment first.";
        }

        return;
    }

    const profile = JSON.parse(savedProfile);

    if (roadmapCareerGoalDisplay) {
        roadmapCareerGoalDisplay.textContent =
            profile.careerGoal || "Not selected";
    }

    if (roadmapCurrentSkillsDisplay) {

        roadmapCurrentSkillsDisplay.innerHTML = "";

        const skillsHeading = document.createElement("h3");
        skillsHeading.textContent = "Technical Skills";

        const skillsList = document.createElement("ul");

        (profile.technicalSkills || []).forEach(function(skill) {
            const listItem = document.createElement("li");
            listItem.textContent = skill;
            skillsList.appendChild(listItem);
        });

        const interestsHeading = document.createElement("h3");
        interestsHeading.textContent = "Areas of Interest";

        const interestsList = document.createElement("ul");

        (profile.interests || []).forEach(function(interest) {
            const listItem = document.createElement("li");
            listItem.textContent = interest;
            interestsList.appendChild(listItem);
        });

        const proficiencyHeading = document.createElement("h3");
        proficiencyHeading.textContent = "Proficiency Levels";

        const proficiencyList = document.createElement("ul");

        Object.entries(profile.proficiency || {}).forEach(function(item) {
            const listItem = document.createElement("li");

            listItem.textContent =
                item[0] + ": " + item[1];

            proficiencyList.appendChild(listItem);
        });

        roadmapCurrentSkillsDisplay.appendChild(skillsHeading);
        roadmapCurrentSkillsDisplay.appendChild(skillsList);

        roadmapCurrentSkillsDisplay.appendChild(interestsHeading);
        roadmapCurrentSkillsDisplay.appendChild(interestsList);

        roadmapCurrentSkillsDisplay.appendChild(proficiencyHeading);
        roadmapCurrentSkillsDisplay.appendChild(proficiencyList);
    }
}

// Run only when the Roadmap page is opened
if (roadmapCareerGoalDisplay) {
    loadRoadmapProfile();
}

/* =====================================
   GENERATE PERSONALIZED CAREER ROADMAP
===================================== */

const generateRoadmapBtn =
    document.getElementById("generateRoadmapBtn");

const roadmapStagesContainer =
    document.getElementById("roadmapStages");

function generatePersonalizedRoadmap() {

    const savedProfile =
        localStorage.getItem("studentSkillProfile");

    if (!savedProfile) {
        alert("Please complete your Skill Assessment first.");
        return;
    }

    const profile = JSON.parse(savedProfile);
    const careerGoal = profile.careerGoal;

    let roadmap = [];

    if (careerGoal === "AI Engineer") {

        roadmap = [
            {
                title: "Stage 1: Programming Foundations",
                duration: "Month 1-2",
                topics: "Python, Mathematics, Statistics and Problem Solving",
                project: "Build a Python Calculator and Data Analysis Tool"
            },
            {
                title: "Stage 2: Machine Learning",
                duration: "Month 3-4",
                topics: "NumPy, Pandas, Machine Learning and Data Visualization",
                project: "Build a Student Performance Prediction Demo"
            },
            {
                title: "Stage 3: Artificial Intelligence",
                duration: "Month 5-6",
                topics: "Neural Networks, Deep Learning and AI Fundamentals",
                project: "Build a Simple AI-Based Recommendation Demo"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "Portfolio, GitHub, Problem Solving and Interview Preparation",
                project: "Publish Your AI Projects in a Portfolio"
            }
        ];

    } else if (careerGoal === "Software Developer") {

        roadmap = [
            {
                title: "Stage 1: Programming Foundations",
                duration: "Month 1-2",
                topics: "C, C++, Java or Python and Data Structures",
                project: "Build a Student Management System"
            },
            {
                title: "Stage 2: Web and Database Development",
                duration: "Month 3-4",
                topics: "HTML, CSS, JavaScript, SQL and Database Design",
                project: "Build a Student Registration Website"
            },
            {
                title: "Stage 3: Application Development",
                duration: "Month 5-6",
                topics: "Backend Development, APIs and Software Testing",
                project: "Build a Full-Stack Web Application"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "Git, GitHub, Coding Practice and Interview Preparation",
                project: "Create a Professional Project Portfolio"
            }
        ];

    } else if (careerGoal === "Data Scientist") {

        roadmap = [
            {
                title: "Stage 1: Foundations",
                duration: "Month 1-2",
                topics: "Python, Mathematics, Statistics and SQL",
                project: "Analyze a Student Performance Dataset"
            },
            {
                title: "Stage 2: Data Analysis",
                duration: "Month 3-4",
                topics: "NumPy, Pandas and Data Visualization",
                project: "Build a Data Analysis Dashboard"
            },
            {
                title: "Stage 3: Machine Learning",
                duration: "Month 5-6",
                topics: "Machine Learning Algorithms and Model Evaluation",
                project: "Build a Simple Prediction Model"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "Portfolio, Case Studies and Interview Preparation",
                project: "Publish Your Data Science Projects"
            }
        ];

    } else if (careerGoal === "Cloud Engineer") {

        roadmap = [
            {
                title: "Stage 1: IT Foundations",
                duration: "Month 1-2",
                topics: "Networking, Linux, Operating Systems and Programming",
                project: "Create a Linux Administration Practice Project"
            },
            {
                title: "Stage 2: Cloud Fundamentals",
                duration: "Month 3-4",
                topics: "Cloud Computing, Virtual Machines and Storage",
                project: "Design a Basic Cloud Architecture"
            },
            {
                title: "Stage 3: Cloud Services",
                duration: "Month 5-6",
                topics: "Cloud Deployment, Security and Automation",
                project: "Deploy a Simple Web Application"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "Cloud Projects, Portfolio and Interview Preparation",
                project: "Document Your Cloud Projects"
            }
        ];

    } else if (careerGoal === "Cybersecurity Analyst") {

        roadmap = [
            {
                title: "Stage 1: Computer Foundations",
                duration: "Month 1-2",
                topics: "Networking, Linux and Operating System Fundamentals",
                project: "Create a Network Concepts Learning Project"
            },
            {
                title: "Stage 2: Security Fundamentals",
                duration: "Month 3-4",
                topics: "Security Principles, Cryptography and Access Control",
                project: "Create a Security Awareness Guide"
            },
            {
                title: "Stage 3: Defensive Security",
                duration: "Month 5-6",
                topics: "Log Analysis, Monitoring and Incident Response Concepts",
                project: "Analyze Sample Security Logs"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "Security Documentation, Portfolio and Interview Preparation",
                project: "Create a Defensive Security Portfolio"
            }
        ];

    } else if (careerGoal === "Web Developer") {

        roadmap = [
            {
                title: "Stage 1: Web Foundations",
                duration: "Month 1-2",
                topics: "HTML, CSS and Responsive Web Design",
                project: "Build a Personal Portfolio Website"
            },
            {
                title: "Stage 2: JavaScript Development",
                duration: "Month 3-4",
                topics: "JavaScript, DOM Manipulation and APIs",
                project: "Build an Interactive To-Do Application"
            },
            {
                title: "Stage 3: Full-Stack Development",
                duration: "Month 5-6",
                topics: "Backend Development, Node.js and SQL",
                project: "Build a Full-Stack Student Application"
            },
            {
                title: "Stage 4: Career Preparation",
                duration: "Month 7-8",
                topics: "GitHub, Portfolio and Interview Preparation",
                project: "Publish Your Web Development Portfolio"
            }
        ];

    } else {

        alert("No roadmap is available for this career goal yet.");
        return;
    }

    roadmapStagesContainer.innerHTML = "";

    const heading = document.createElement("h3");
    heading.textContent = "Personalized Roadmap: " + careerGoal;

    roadmapStagesContainer.appendChild(heading);

    roadmap.forEach(function(stage) {

        const stageDiv = document.createElement("div");
        stageDiv.className = "roadmap-stage";

        const title = document.createElement("h3");
        title.textContent = stage.title;

        const duration = document.createElement("p");
        duration.textContent = "Suggested Timeline: " + stage.duration;

        const topics = document.createElement("p");
        topics.textContent = "Learning Topics: " + stage.topics;

        const project = document.createElement("p");
        project.textContent = "Recommended Project: " + stage.project;

        stageDiv.appendChild(title);
        stageDiv.appendChild(duration);
        stageDiv.appendChild(topics);
        stageDiv.appendChild(project);

        roadmapStagesContainer.appendChild(stageDiv);

    });

    localStorage.setItem(
        "generatedCareerRoadmap",
        JSON.stringify(roadmap)
    );
}

if (generateRoadmapBtn) {
    generateRoadmapBtn.addEventListener(
        "click",
        generatePersonalizedRoadmap
    );
}

/* =====================================
   LOAD PREVIOUSLY GENERATED ROADMAP
===================================== */

function loadSavedCareerRoadmap() {

    const savedRoadmap =
        localStorage.getItem("generatedCareerRoadmap");

    if (!savedRoadmap || !roadmapStagesContainer) {
        return;
    }

    const roadmap = JSON.parse(savedRoadmap);

    roadmapStagesContainer.innerHTML = "";

    const heading = document.createElement("h3");

    heading.textContent = "Your Previously Generated Career Roadmap";

    roadmapStagesContainer.appendChild(heading);

    roadmap.forEach(function(stage) {

        const stageDiv = document.createElement("div");
        stageDiv.className = "roadmap-stage";

        const title = document.createElement("h3");
        title.textContent = stage.title;

        const duration = document.createElement("p");
        duration.textContent =
            "Suggested Timeline: " + stage.duration;

        const topics = document.createElement("p");
        topics.textContent =
            "Learning Topics: " + stage.topics;

        const project = document.createElement("p");
        project.textContent =
            "Recommended Project: " + stage.project;

        stageDiv.appendChild(title);
        stageDiv.appendChild(duration);
        stageDiv.appendChild(topics);
        stageDiv.appendChild(project);

        roadmapStagesContainer.appendChild(stageDiv);

    });
}

// Load saved roadmap when Roadmap page opens
if (roadmapStagesContainer) {
    loadSavedCareerRoadmap();
}

// =====================================
// CONNECT FRONTEND WITH BACKEND API
// =====================================

async function checkBackendConnection() {

    try {

        const response = await fetch(
            "http://localhost:3000/api/status"
        );

        const data = await response.json();

        if (data.success) {

            console.log(
                "Backend Connected:",
                data.message
            );

        }

    } catch (error) {

        console.error(
            "Backend Connection Failed:",
            error
        );

    }

}

// Check backend only when Dashboard is opened
if (document.getElementById("careerGoalDisplay") === null &&
    document.querySelector(".mentor-container") === null &&
    window.location.pathname.endsWith("/dashboard.html")) {

    checkBackendConnection();

}
// =====================================
// DISPLAY LOGGED-IN STUDENT DETAILS
// =====================================

(async function displayLoggedInStudent() {
    if (!document.getElementById("dashboardStudentName")) {
        return;
    }

    try {
        const response = await fetch(
            "http://localhost:3000/api/me",
            {
                method: "GET",
                credentials: "include"
            }
        );

        if (!response.ok) {
            window.location.href = "login.html";
            return;
        }

        const result = await response.json();

        if (!result.success || !result.student) {
            window.location.href = "login.html";
            return;
        }

        const student = result.student;

        document.getElementById("dashboardStudentName").textContent =
            student.studentName;

        document.getElementById("dashboardDepartment").textContent =
            student.department + " Student";

        document.getElementById("dashboardWelcome").textContent =
            "Welcome back, " + student.studentName + "! 👋";

        const yearNames = {
            1: "1st Year",
            2: "2nd Year",
            3: "3rd Year",
            4: "4th Year"
        };

        document.getElementById("dashboardYear").textContent =
            yearNames[student.year] || student.year + " Year";

        document.getElementById("dashboardSemester").textContent =
            "Semester " + student.semester;

    } catch (error) {
        console.error("Dashboard Authentication Error:", error);
        alert("Unable to connect to the backend. Please try again.");
    }
})();

// =====================================
// STUDENT LOGOUT
// =====================================

const logoutBtn = document.getElementById("logoutBtn");

if (logoutBtn) {
    logoutBtn.addEventListener("click", async function(event) {
        event.preventDefault();

        try {
            const response = await fetch(
                "http://localhost:3000/api/logout",
                {
                    method: "POST",
                    credentials: "include"
                }
            );

            const result = await response.json();

            if (response.ok && result.success) {
                alert("You have successfully logged out.");
                window.location.href = "login.html";
            } else {
                alert(result.message || "Logout failed. Please try again.");
            }

        } catch (error) {
            console.error("Logout Error:", error);
            alert("Unable to connect to the backend. Please try again.");
        }
    });
}
